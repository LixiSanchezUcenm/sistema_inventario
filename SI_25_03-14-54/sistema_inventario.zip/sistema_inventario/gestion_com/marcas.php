<?php
include '../conexion.php';

// Verificar si el usuario es administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='../dashboard.php';</script>";
    exit();
}

// Agregar nueva marca
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = trim($_POST['nombre']);

    if (!empty($nombre)) {
        $stmt = $conn->prepare("INSERT INTO marcas_computadoras (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);

        if ($stmt->execute()) {
            echo "<script>alert('Marca agregada exitosamente'); window.location.href='menu.php';</script>";
        } else {
            echo "<script>alert('Error al agregar la marca'); window.location.href='menu.php';</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('El campo nombre no puede estar vacío');</script>";
    }
}

// Eliminar una marca
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    $stmt = $conn->prepare("DELETE FROM marcas_computadoras WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Marca eliminada exitosamente'); window.location.href='menu.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar la marca'); window.location.href='menu.php';</script>";
    }
    $stmt->close();
}

// Obtener todas las marcas
$result = $conn->query("SELECT * FROM marcas_computadoras");
?>

<div class="container mt-5">
    <h2 class="text-center">Gestión de Marcas de Computadoras</h2>

    <form method="POST" class="mb-3">
        <div class="mb-3">
            <label class="form-label">Nombre de la marca</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['nombre']) ?></td>
                <td>
                    <a href="?eliminar=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que deseas eliminar esta marca?')">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
