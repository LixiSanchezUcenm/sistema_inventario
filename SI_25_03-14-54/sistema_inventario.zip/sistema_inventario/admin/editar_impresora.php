<?php
include '../conexion.php';


// menu header
include '../includes/header.php';


// Obtener el ID de la impresora a editar
if (!isset($_GET['id'])) {
    echo "ID de impresora no proporcionado.";
    exit;
}
$id = $_GET['id'];

// Obtener datos de la impresora
$query = "SELECT * FROM Impresoras WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$impresora = $result->fetch_assoc();

if (!$impresora) {
    echo "Impresora no encontrada.";
    exit;
}

// Obtener marcas y tipos de impresoras para los select
$marcas = $conn->query("SELECT * FROM Marcas");
$tipos = $conn->query("SELECT * FROM Tipos_Impresoras");

// Procesar formulario de actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial = $_POST['serial'];
    $modelo = $_POST['modelo'];
    $id_marca = $_POST['id_marca'];
    $id_tipo = $_POST['id_tipo'];

    $updateQuery = "UPDATE Impresoras SET serial=?, modelo=?, id_marca=?, id_tipo=? WHERE id=?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssiii", $serial, $modelo, $id_marca, $id_tipo, $id);
    
    if ($stmt->execute()) {
        header("Location: crud_impresoras.php?mensaje=Impresora actualizada correctamente");
        exit;
    } else {
        echo "Error al actualizar la impresora.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Impresora</title>
	    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

	
			 <!-- Menu header -->
		    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	

</head>
<body>
	
	<!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>
	
	
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="text-center text-primary">Editar Impresora</h3>
            <form method="POST">
				
				
                <div class="mb-3">
                    <label class="form-label">Serial</label>
                    <input type="text" name="serial" class="form-control" value="<?php echo $impresora['serial']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Modelo</label>
                    <input type="text" name="modelo" class="form-control" value="<?php echo $impresora['modelo']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Marca</label>
                    <select name="id_marca" class="form-select" required>
                        <?php while ($marca = $marcas->fetch_assoc()) { ?>
                            <option value="<?php echo $marca['id']; ?>" <?php echo ($marca['id'] == $impresora['id_marca']) ? 'selected' : ''; ?>>
                                <?php echo $marca['nombre']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tipo</label>
                    <select name="id_tipo" class="form-select" required>
                        <?php while ($tipo = $tipos->fetch_assoc()) { ?>
                            <option value="<?php echo $tipo['id']; ?>" <?php echo ($tipo['id'] == $impresora['id_tipo']) ? 'selected' : ''; ?>>
                                <?php echo $tipo['tipo']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success">Actualizar</button>
                    <a href="crud_impresoras.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
