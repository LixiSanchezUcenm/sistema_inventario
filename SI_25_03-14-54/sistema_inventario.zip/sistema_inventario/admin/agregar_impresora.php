<?php

include '../conexion.php';

// menu header
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Impresoras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	
			 <!-- Menu header -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
	
</head>

</html>

<?php
// agregar_impresora.php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial = $_POST['serial'];
    $modelo = $_POST['modelo'];
    $id_marca = $_POST['id_marca'];
    $id_tipo = $_POST['id_tipo'];
    
    $insert = "INSERT INTO Impresoras (serial, modelo, id_marca, id_tipo) VALUES ('$serial', '$modelo', '$id_marca', '$id_tipo')";
    if (mysqli_query($conn, $insert)) {
        echo "<script>alert('Impresora agregada exitosamente'); window.location.href='crud_impresoras.php';</script>";
    } else {
        echo "<script>alert('Error al agregar impresora');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Impresora</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	
	<!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>
	
	
    <div class="container mt-5">
    <h2 class="text-center">Agregar Impresora</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label">Serial</label>
            <input type="text" name="serial" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Modelo</label>
            <input type="text" name="modelo" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Marca</label>
            <select name="id_marca" class="form-control" required>
                <?php
                $marcas = mysqli_query($conn, "SELECT * FROM Marcas");
                while ($marca = mysqli_fetch_assoc($marcas)) {
                    echo "<option value='{$marca['id']}'>{$marca['nombre']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Tipo</label>
            <select name="id_tipo" class="form-control" required>
                <?php
                $tipos = mysqli_query($conn, "SELECT * FROM Tipos_Impresoras");
                while ($tipo = mysqli_fetch_assoc($tipos)) {
                    echo "<option value='{$tipo['id']}'>{$tipo['tipo']}</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="crud_impresoras.php" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>