<?php
include '../conexion.php';


include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Obtener lista de impresoras
$query = "SELECT Impresoras.*, Marcas.nombre AS marca, Tipos_Impresoras.tipo AS tipo FROM Impresoras
          JOIN Marcas ON Impresoras.id_marca = Marcas.id
          JOIN Tipos_Impresoras ON Impresoras.id_tipo = Tipos_Impresoras.id";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Impresoras</title>
	
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">Gestión de Impresoras</h2>
		     <!-- Mostrar cantidad de registros obtenidos -->
        <?php 
        $num_rows = mysqli_num_rows($result);
        echo "<p class='text-center'>Registros encontrados: <strong>$num_rows</strong></p>"; 
        ?>

        <!-- Input de búsqueda -->
        <input type="text" id="buscador" class="form-control mb-3" placeholder="Buscar en cualquier campo...">

        <a href="agregar_impresora.php" class="btn btn-success mb-3">Agregar Impresora</a>
		        <a href="../garantias/listar_gt_impresora.php" class="btn btn-success mb-3">Listado Garantias</a>


        <table class="table table-bordered" id="tablaImpresoras">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Serial</th>
                    <th>Modelo</th>
                    <th>Marca</th>
                    <th>Tipo</th>
                    <th>Estado</th>
                    <th>Ubicación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['serial']; ?></td>
                        <td><?php echo $row['modelo']; ?></td>
                        <td><?php echo $row['marca']; ?></td>
                        <td><?php echo $row['tipo']; ?></td>
                        <td><?php echo $row['estado_actual']; ?></td>
                        <td><?php echo $row['ubicacion']; ?></td>
     
							
							                        
<td>
    <div class="d-flex gap-2">
        <a href="editar_impresora.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
        <a href="eliminar_impresora.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta computadora?');">Eliminar</a>
        <a href="../garantias/garantia_impre.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Garantía</a>
    </div>
</td>



                   
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        document.getElementById("buscador").addEventListener("keyup", function() {
            let filtro = this.value.toLowerCase();
            let filas = document.querySelectorAll("#tablaImpresoras tbody tr");

            filas.forEach(function(fila) {
                let textoFila = fila.textContent.toLowerCase();
                fila.style.display = textoFila.includes(filtro) ? "" : "none";
            });
        });
    </script>

</body>
</html>
