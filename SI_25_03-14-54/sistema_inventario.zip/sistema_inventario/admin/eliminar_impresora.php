<?php
include '../conexion.php';

if (!isset($_GET['id'])) {
    echo "ID de impresora no proporcionado.";
    exit;
}

$id = $_GET['id'];

// Eliminar la impresora de la base de datos
$query = "DELETE FROM Impresoras WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: crud_impresoras.php?mensaje=Impresora eliminada correctamente");
    exit;
} else {
    echo "Error al eliminar la impresora.";
}
?>
