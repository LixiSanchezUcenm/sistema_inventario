<?php
include '../conexion.php';

if (!isset($_GET['serial']) || empty($_GET['serial'])) {
    die("No se proporcionó un serial válido.");
}

$serial = $conn->real_escape_string($_GET['serial']);

$sql = "SELECT 
    ac.id AS id_asignacion,
    c.serial AS computadora_serial,
    c.modelo AS computadora_modelo,
    c.disco AS computadora_disco,
    c.ram AS computadora_ram,
    c.procesador AS computadora_procesador,
    c.sistema_operativo AS computadora_sistema_operativo,
    m.nombre AS marcas_computadoras,
    t.tipo AS tipo_computadora,
    u.usuario AS usuario,
    u.nombre AS nombre_usuario,
    u.jefe_inmediato AS jefe_inmediato,
    d.nombre AS departamento_nombre,
    u.puesto AS puesto_usuario,
    p.nombre AS planta_asignacion,
    e.nombre AS nombre_empresa, 
    ac.fecha_asignacion,
    ac.causa_solicitud,
    ac.procedencia,
    ac.observaciones,
    GROUP_CONCAT(tc.nombre, ' - ', co.modelo, ' - ', co.serial SEPARATOR '|') AS componentes_asignados
FROM asignaciones_computadora ac
JOIN computadoras c ON ac.id_computadora = c.id
JOIN usuarios u ON ac.id_usuario = u.usuario
LEFT JOIN departamentos d ON u.departamento_id = d.id
LEFT JOIN asignaciones_componentes acom ON c.id = acom.id_computadora AND acom.activo = 1
LEFT JOIN componentes co ON acom.id_componente = co.id
LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
LEFT JOIN plantas p ON ac.planta = p.id
LEFT JOIN empresas e ON p.id_empresa = e.id  -- CORRECCIÓN AQUÍ
LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
WHERE ac.activo = 1 AND c.serial = '$serial'
GROUP BY ac.id, c.id, u.usuario, p.id, d.nombre, e.nombre
ORDER BY tc.nombre ASC;";


$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    die("No se encontraron asignaciones para esta computadora.");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignación de Equipo Informático</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
		
		
        body {font-family: Arial, sans-serif;
            max-width: 800px; /* Ajusta a tamaño carta */
            margin: auto;
            background-color: #f8f9fa; }
		
		
		
        .asignacion-container { border: 0px solid #000; padding: 20px; max-width: 900px; margin: auto; 
		
		  background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		
		}
		
        .titulo { text-align: center; font-weight: bold; font-size: 14px; }
        .seccion { border-bottom: 1px ; padding-bottom: 5px; margin-bottom: 0px; font-size:12px; }

.tabla-usuario th, .tabla-usuario td { text-align: center; padding: 2px; font-size:12px;   border-bottom: 1px solid #000;  }
.tabla-computadora th, .tabla-computadora td { text-align: center; padding: 2px; font-size:12px;   border-bottom: 1px ;  }

 .tabla-componentes th, .tabla-componentes td { text-align: center; border: 0px solid #000; padding: 2px; font-size:12px; }
        
        /* Ocultar el botón de impresión al imprimir */
        @media print {
            .btn-imprimir {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div class="asignacion-container">
	
	
 <div style="display: flex; align-items: center; border-top: 3px solid orange; border-bottom: 3px solid blue; padding: 10px; text-align: center;">
    <img src="../logo.png" alt="Logo" style="height: 40px; margin-right: 10px;">
	 
	 
	 
	     <div style="flex: 1; text-align: center; font-size: 14px; font-weight: bold;">
			 <?= ($row['nombre_empresa']) ?><br>ASIGNACIÓN DE EQUIPO INFORMÁTICO
    </div>
</div>

<div class="seccion">
    <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px;">Información del Usuario</strong><br>
    <table class="table tabla-usuario" style="border-collapse: collapse; width: 100%;">
		
					
					
        <tr>
            <th style="text-align: left; padding-right: 8px; border-bottom: 1px; ">Fecha:</th>
            <td style="padding-left: 8px;"><?= $row["fecha_asignacion"] ?></td>
			
            <th style="text-align: left; padding-right: 8px; border-bottom: 1px; ">Asignado a:</th>
            <td style="padding-left: 8px;"><?= $row["nombre_usuario"] ?></td>
        </tr>
        <tr>
            <th style="text-align: left; padding-right: 8px; border-bottom: 1px;">Planta:</th>
            <td style="padding-left: 8px;"><?= $row["planta_asignacion"] ?></td>
			
            <th style="text-align: left; padding-right: 8px; border-bottom: 1px ;">Jefe Inmediato:</th>
            <td style="padding-left: 8px;"><?= $row["jefe_inmediato"] ?></td>
        </tr>
        <tr>
            <th style="text-align: left; padding-right: 8px; border-bottom: 1px ;">Departamento:</th>
            <td style="padding-left: 8px;"><?= $row["departamento_nombre"] ?></td>
        </tr>
    </table>
</div>
<div class="seccion">
     <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px;">Descripción del Equipo</strong><br>
    <table class="table tabla-computadora" style="border-collapse: collapse; width: 100%;">
        <tr>
            <th style="text-align: left; padding-right: 8px;">Tipo:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["tipo_computadora"] ?></td>
			
            <th style="text-align: left; padding-right: 8px;">Serial:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_serial"] ?></td>
        </tr>
        <tr>
            <th style="text-align: left; padding-right: 8px;">Marca:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["marcas_computadoras"] ?></td>
            <th style="text-align: left; padding-right: 8px;">RAM:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_ram"] ?></td>
        </tr>
        <tr>
            <th style="text-align: left; padding-right: 8px;">Modelo:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_modelo"] ?></td>
            <th style="text-align: left; padding-right: 8px;">Procesador:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_procesador"] ?></td>
        </tr>
        <tr>
            <th style="text-align: left; padding-right: 8px;">Disco:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_disco"] ?></td>
            <th style="text-align: left; padding-right: 8px;">Sistema Operativo:</th>
            <td style="padding-left: 8px; border-bottom: 1px solid #000;"><?= $row["computadora_sistema_operativo"] ?></td>
        </tr>
    </table>
</div>
    
    <div class="seccion">
		
		      <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px;">Información del Componentes</strong><br>

        <table class="table table-bordered tabla-componentes">
            <thead>
                <tr><th>Nombre</th><th>Modelo</th><th>Serial</th></tr>
            </thead>
            <tbody>
                <?php 
                if (!empty($row["componentes_asignados"])) {
                    $componentes = explode("|", $row["componentes_asignados"]);
                    foreach ($componentes as $componente) {
                        list($nombre, $modelo, $serial) = explode(" - ", $componente);
                        echo "<tr><td>$nombre</td><td>$modelo</td><td>$serial</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>Sin componentes asignados</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
	
	
	
<div class="seccion" style="margin-bottom: 5px;">
      <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px; text-align: center;">Causa de Solicitud de Equipo</strong><br>
    <p style="margin: 2px 0; text-align: center; border-bottom: 1px solid #ccc;">
        <?= !empty($row["causa_solicitud"]) ? $row["causa_solicitud"] : "No especificada" ?>
    </p>
</div>

<div class="seccion" style="margin-bottom: 5px;">
      <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px;text-align: center;">Procedencia</strong><br>
    <p style="margin: 2px 0;text-align: center; border-bottom: 1px solid #ccc;">
        <?= !empty($row["procedencia"]) ? $row["procedencia"] : "No especificada" ?>
    </p>
</div>

<div class="seccion" style="margin-bottom: 5px;">
      <strong style="background: #f0f0f0; padding: 5px; display: inline-block;width: 100%; margin-top: 5px;text-align: center;">Observaciones</strong><br>
    <p style="margin: 2px 0; text-align: center; border-bottom: 1px solid #ccc;">
        <?= !empty($row["observaciones"]) ? $row["observaciones"] : "No hay observaciones" ?>
    </p>
</div>

	
	
	
<div class="seccion">
    <table class="table table-borderless text-center" style="margin-top: 35px; width: 100%;">
        <tr>
            <td style="font-size: 11px; display: flex; align-items: center;">
                <strong>Representante IT:</strong> 
                <span style="flex: 1; border-bottom: 1px solid black; margin-left: 10px; margin-right: 20px;"></span>
                <strong>Jefe IT:</strong> 
                <span style="flex: 1; border-bottom: 1px solid black; margin-left: 10px;"></span>
            </td>
        </tr>
        <tr>
            <td style="font-size: 11px; display: flex; align-items: center;margin-top: 35px; ">
                <strong>Usuario:</strong> 
                <span style="flex: 1; border-bottom: 1px solid black; margin-left: 10px; margin-right: 30px;"></span>
                <strong>Jefe de Departamento:</strong> 
                <span style="flex: 1; border-bottom: 1px solid black; margin-left: 10px;"></span>
            </td>
        </tr>
    </table>
</div>
    <!-- Botón de impresión -->
    <div class="text-center mt-3">
        <button onclick="window.print();" class="btn btn-primary btn-imprimir">Imprimir Asignación</button>
    </div>
</div>
	

</body>
</html>
