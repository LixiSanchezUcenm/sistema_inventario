<?php
include '../conexion.php';
include '../includes/header.php';

$sql = "SELECT 
            ac.id AS id_asignacion,
            c.serial AS computadora_serial,
            c.modelo AS computadora_modelo,
            c.disco AS computadora_disco,
            c.ram AS computadora_ram,
            c.procesador AS computadora_procesador,
            c.sistema_operativo AS computadora_sistema_operativo,
            m.nombre AS marcas_computadoras,
            t.tipo AS tipo_computadora,
            u.nombre AS nombre_usuario,
            u.puesto AS puesto_usuario,
            p.nombre AS planta_asignacion,
            ac.fecha_asignacion,
            GROUP_CONCAT(CONCAT(tc.nombre, ' - ', co.modelo, ' - ', co.serial) SEPARATOR ', ') AS componentes_asignados
        FROM asignaciones_computadora ac
        JOIN computadoras c ON ac.id_computadora = c.id
        JOIN usuarios u ON ac.id_usuario = u.usuario
        LEFT JOIN asignaciones_componentes acom ON c.id = acom.id_computadora
        LEFT JOIN componentes co ON acom.id_componente = co.id
        LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
        LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
        LEFT JOIN plantas p ON ac.planta = p.id
        LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
        WHERE ac.activo = 1
        GROUP BY ac.id, c.serial, c.modelo, c.disco, c.ram, c.procesador, c.sistema_operativo, 
                 m.nombre, t.tipo, u.nombre, u.puesto, p.nombre, ac.fecha_asignacion";

$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Asignaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
    <script>
        function filtrarTabla() {
            var input, filtro, tabla, tr, td, i, j, txtValue;
            input = document.getElementById("buscador");
            filtro = input.value.toLowerCase();
            tabla = document.getElementById("tablaAsignaciones");
            tr = tabla.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) { // Comenzamos en 1 para saltar el encabezado
                tr[i].style.display = "none"; // Ocultamos la fila por defecto
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j]) {
                        txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toLowerCase().indexOf(filtro) > -1) {
                            tr[i].style.display = "";
                            break; // Si encuentra una coincidencia, muestra la fila y deja de revisar más columnas
                        }
                    }
                }
            }
        }
    </script>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container mt-5">
        <h2>Listado de Asignaciones de Computadoras</h2>

        <input type="text" id="buscador" onkeyup="filtrarTabla()" class="form-control mb-3" placeholder="Buscar asignación...">

		
	
		<a href="exportar_coputadora.php" class="btn btn-success">
    <i class="fas fa-file-excel"></i> Exportar Computadoras
</a>


		
        <table class="table table-striped" id="tablaAsignaciones">
            <thead class="table-dark">
                <tr>
                    <th>Serial Computadora</th>
                    <th>Modelo Computadora</th>
                    <th>Nombre Usuario</th>
                    <th>Planta</th>
                    <th>Fecha Asignación</th>
                    <th>Ver Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["computadora_serial"] . "</td>";
                        echo "<td>" . $row["computadora_modelo"] . "</td>";
                        echo "<td>" . $row["nombre_usuario"] . "</td>";
                        echo "<td>" . $row["planta_asignacion"] . "</td>"; 
                        echo "<td>" . $row["fecha_asignacion"] . "</td>";
                        echo "<td><a href='ver_asignacion.php?serial=" . urlencode($row["computadora_serial"]) . "'>🔍 Ver</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No hay asignaciones registradas.</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
