<?php
include '../conexion.php';
include '../includes/header.php';

// Consulta SQL para obtener datos completos con la planta
$sql = "SELECT 
            a.id AS id_asignacion,
            u.nombre AS nombre_usuario, 
            u.telefono AS telefono_usuario, 
            u.jefe_inmediato, 
            u.puesto, 
            i.serial AS serie_impresora, 
            i.modelo AS modelo_impresora, 
            m.nombre AS marca_impresora, 
            p.PDV, 
            p.descripcion AS nombre_pdv, 
            pl.nombre AS nombre_planta, 
            a.fecha_asignacion, 
            a.asignado_por,
            a.fecha_devolucion
        FROM Asignaciones a
        JOIN Usuarios u ON a.usuario = u.usuario
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Marcas m ON i.id_marca = m.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        JOIN Plantas pl ON p.id_planta = pl.id
        WHERE a.activo = 1
        ORDER BY a.fecha_asignacion DESC";

$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Asignaciones de Impresoras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
    <script>
        function filtrarTabla() {
            var input, filtro, tabla, tr, td, i, j, txtValue;
            input = document.getElementById("buscador");
            filtro = input.value.toLowerCase();
            tabla = document.getElementById("tablaAsignaciones");
            tr = tabla.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) { // Comenzamos en 1 para saltar el encabezado
                tr[i].style.display = "none"; // Ocultamos la fila por defecto
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j]) {
                        txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toLowerCase().indexOf(filtro) > -1) {
                            tr[i].style.display = "";
                            break; // Si encuentra una coincidencia, muestra la fila y deja de revisar más columnas
                        }
                    }
                }
            }
        }
    </script>
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container mt-5">
        <h2>Listado de Asignaciones de Impresoras</h2>

        <input type="text" id="buscador" onkeyup="filtrarTabla()" class="form-control mb-3" placeholder="Buscar asignación...">

		
				
	
		<a href="exportar_excel_impr.php" class="btn btn-success">
    <i class="fas fa-file-excel"></i> Exportar Impresoras
</a>


        <table class="table table-striped" id="tablaAsignaciones">
            <thead class="table-dark">
                <tr>
                    <th>Serial Impresora</th>
                    <th>Modelo Impresora</th>
                    <th>Marca</th>
                    <th>Nombre Usuario</th>
                    <th>Planta</th>
                    <th>Fecha Asignación</th>
                    <th>Ver Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["serie_impresora"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["modelo_impresora"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["marca_impresora"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["nombre_usuario"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["nombre_planta"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["fecha_asignacion"]) . "</td>";
                        echo "<td><a href='ver_impresora.php?id=" . urlencode($row["id_asignacion"]) . "'>🔍 Ver</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No hay asignaciones registradas.</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
