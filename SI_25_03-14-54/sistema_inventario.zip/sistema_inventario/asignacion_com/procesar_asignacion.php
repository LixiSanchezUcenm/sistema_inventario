<?php
include '../conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$id_computadora = isset($_POST['id_computadora']) ? $_POST['id_computadora'] : null;
$usuario = isset($_POST['usuario']) ? $_POST['usuario'] : null;
$planta = isset($_POST['planta']) ? $_POST['planta'] : null;
$asignado_por = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : 'Desconocido';
$causa_solicitud = isset($_POST['causa_solicitud']) ? $_POST['causa_solicitud'] : '';
$procedencia = isset($_POST['procedencia']) ? $_POST['procedencia'] : '';
$observaciones = isset($_POST['observaciones']) ? $_POST['observaciones'] : '';

    // Depuración para ver qué datos se reciben
    echo "<pre>";
    var_dump($_POST);
    echo "</pre>";

    // Validación: si falta la planta, mostrar error
    if (!$planta) {
        die("Error: No se recibió el campo 'Planta'. Verifica el formulario.");
    }

    // Verificar que la computadora no esté asignada
    $sql_check = "SELECT asignada FROM computadoras WHERE id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("i", $id_computadora);
    $stmt_check->execute();
    $stmt_check->bind_result($asignada);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($asignada) {
        echo "<script>alert('La computadora ya está asignada.'); window.location.href='asignar_computadora.php';</script>";
        exit();
    }

    // Insertar en Asignaciones_Computadora
    $sql = "INSERT INTO asignaciones_computadora (id_computadora, id_usuario, planta, asignado_por, causa_solicitud, procedencia, observaciones) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die("Error al preparar la consulta: " . $conn->error);
    }

    $stmt->bind_param("issssss", $id_computadora, $usuario, $planta, $asignado_por, $causa_solicitud, $procedencia, $observaciones);

    if (!$stmt->execute()) {
        die("Error al ejecutar la consulta: " . $stmt->error);
    }

    // Actualizar el estado de la computadora a asignada
    $sql_update = "UPDATE computadoras SET ubicacion = ?, asignada = 1 WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("si", $planta, $id_computadora);
    $stmt_update->execute();

    echo "<script>alert('Computadora asignada correctamente.'); window.location.href='asignar_computadora.php';</script>";
    exit();
}
?>
