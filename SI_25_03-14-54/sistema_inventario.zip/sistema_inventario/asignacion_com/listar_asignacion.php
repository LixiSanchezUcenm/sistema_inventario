<?php
include '../conexion.php'; // Asegúrate de que tienes un archivo de conexión a la base de datos

$sql = "SELECT 
            ac.id AS id_asignacion,
            c.serial AS computadora_serial,
            c.modelo AS computadora_modelo,
            c.disco AS computadora_disco,
            c.ram AS computadora_ram,
            c.procesador AS computadora_procesador,
            c.sistema_operativo AS computadora_sistema_operativo,
            m.nombre AS marcas_computadoras,
            t.tipo AS tipo_computadora,
            u.usuario AS usuario,
            u.nombre AS nombre_usuario,
            u.puesto AS puesto_usuario,
            p.nombre AS planta_asignacion,  -- Nombre de la planta
            ac.fecha_asignacion,
            GROUP_CONCAT(CONCAT(tc.nombre, ' - ', co.modelo, ' - ', co.serial) SEPARATOR ', ') AS componentes_asignados
			
        FROM asignaciones_computadora ac
        JOIN computadoras c ON ac.id_computadora = c.id
        JOIN usuarios u ON ac.id_usuario = u.usuario
        LEFT JOIN asignaciones_componentes acom ON c.id = acom.id_computadora
        LEFT JOIN componentes co ON acom.id_componente = co.id
        LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
        LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
        LEFT JOIN plantas p ON ac.planta = p.id  -- Nombre de la planta
        LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
        WHERE ac.activo = 1
        GROUP BY ac.id, c.serial, c.modelo, c.disco, c.ram, c.procesador, c.sistema_operativo, m.nombre, t.tipo, u.usuario, u.nombre, u.puesto, p.nombre, ac.fecha_asignacion";





$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Asignaciones</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Listado de Asignaciones de Computadoras</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Serial Computadora</th>
                <th>Modelo Computadora</th>
                <th>Disco</th>
                <th>RAM</th>
                <th>Procesador</th>
                <th>Sistema Operativo</th>
                <th>Marca </th>
                <th>Tipo</th>
                <th>Usuario</th>
                <th>Nombre Usuario</th>
                <th>Puesto</th>
                <th>Planta</th>
                <th>Fecha Asignación</th>
                <th>Componentes Asignados</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_asignacion"] . "</td>";
                    echo "<td>" . $row["computadora_serial"] . "</td>";
                    echo "<td>" . $row["computadora_modelo"] . "</td>";
                    echo "<td>" . $row["computadora_disco"] . "</td>";
                    echo "<td>" . $row["computadora_ram"] . "</td>";
                    echo "<td>" . $row["computadora_procesador"] . "</td>";
                    echo "<td>" . $row["computadora_sistema_operativo"] . "</td>";
                    echo "<td>" . $row["marcas_computadoras"] . "</td>";
                    echo "<td>" . $row["tipo_computadora"] . "</td>";
                    echo "<td>" . $row["usuario"] . "</td>";
                    echo "<td>" . $row["nombre_usuario"] . "</td>";
                    echo "<td>" . $row["puesto_usuario"] . "</td>";
                    echo "<td>" . $row["planta_asignacion"] . "</td>";
                    echo "<td>" . $row["fecha_asignacion"] . "</td>";
                    echo "<td>" . ($row["componentes_asignados"] ? $row["componentes_asignados"] : "Sin componentes") . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='15'>No hay asignaciones registradas.</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
