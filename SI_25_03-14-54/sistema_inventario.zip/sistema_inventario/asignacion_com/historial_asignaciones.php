<?php
include '../conexion.php';

// Menu header
include '../includes/header.php';

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener datos completos con la empresa y la planta
$sql = "SELECT 
            ac.id AS id_asignacion,
            e.nombre AS nombre_empresa,  
            p.nombre AS nombre_planta,
            c.serial AS serie_computadora,
            c.modelo AS modelo_computadora,
            c.disco AS computadora_disco,
            c.ram AS computadora_ram,
            c.procesador AS computadora_procesador,
            c.sistema_operativo AS computadora_sistema_operativo,
            m.nombre AS marca_computadora,
            t.tipo AS tipo_computadora,
            u.usuario AS usuario,
            u.nombre AS nombre_usuario,
            u.telefono AS telefono_usuario,
            u.jefe_inmediato,
            u.puesto AS puesto_usuario,
            ac.fecha_asignacion,
            ac.asignado_por,
            ac.fecha_devolucion,
            GROUP_CONCAT(CONCAT(tc.nombre, ' - ', co.modelo, ' - ', co.serial) SEPARATOR ', ') AS componentes_asignados
        FROM asignaciones_computadora ac
        JOIN computadoras c ON ac.id_computadora = c.id
        JOIN usuarios u ON ac.id_usuario = u.usuario
        LEFT JOIN asignaciones_componentes acom ON c.id = acom.id_computadora
        LEFT JOIN componentes co ON acom.id_componente = co.id
        LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
        LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
        LEFT JOIN plantas p ON ac.planta = p.id  
        LEFT JOIN empresas e ON p.id_empresa = e.id  
        LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
        WHERE ac.activo = 1
        GROUP BY ac.id, e.nombre, p.nombre, c.serial, c.modelo, c.disco, c.ram, c.procesador, 
                 c.sistema_operativo, m.nombre, t.tipo, u.usuario, u.nombre, u.telefono, 
                 u.jefe_inmediato, u.puesto, ac.fecha_asignacion, ac.asignado_por, ac.fecha_devolucion";

$result = $conn->query($sql);

// Verificar si la consulta tuvo errores
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Asignaciones</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">

    <style>
        .table-responsive {
            max-height: 500px; /* Ajusta la altura según necesidad */
            overflow-y: auto;
        }
    </style>
</head>
<body>

    <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Historial de Asignaciones</h2>

        <input type="text" id="search" class="form-control mb-3" placeholder="Buscar en cualquier campo...">

		
		
        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Empresa</th>
                        <th>Planta</th>
                        <th>Serie</th>
                        <th>Modelo</th>
                        <th>Marca</th>
                        <th>Tipo</th>
                        <th>Usuario</th>
                        <th>Teléfono</th>
                        <th>Jefe Inmediato</th>
                        <th>Puesto</th>
                        <th>Fecha Asignación</th>
                        <th>Asignado Por</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nombre_empresa']) ?></td>
                            <td><?= htmlspecialchars($row['nombre_planta']) ?></td>
                            <td><?= htmlspecialchars($row['serie_computadora']) ?></td>
                            <td><?= htmlspecialchars($row['modelo_computadora']) ?></td>
                            <td><?= htmlspecialchars($row['marca_computadora']) ?></td>
                            <td><?= htmlspecialchars($row['tipo_computadora']) ?></td>
                            <td><?= htmlspecialchars($row['nombre_usuario']) ?></td>
                            <td><?= htmlspecialchars($row['telefono_usuario']) ?></td>
                            <td><?= htmlspecialchars($row['jefe_inmediato']) ?></td>
                            <td><?= htmlspecialchars($row['puesto_usuario']) ?></td>
                            <td><?= htmlspecialchars($row['fecha_asignacion']) ?></td>
                            <td><?= htmlspecialchars($row['asignado_por']) ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if (empty($row['fecha_devolucion'])) { ?>
                                        <form method="POST" action="finalizar_asignacion.php" class="d-inline">
                                            <input type="hidden" name="id_asignacion" value="<?= $row['id_asignacion'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Finalizar</button>
                                        </form>
                                    <?php } else { ?>
                                        <span class="text-success">Finalizada</span>
                                    <?php } ?>
                                    <a href="historial.php?serial=<?= urlencode($row['serie_computadora']) ?>" class="btn btn-info btn-sm ms-2">Asignaciones</a>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#search").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#tableBody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>
