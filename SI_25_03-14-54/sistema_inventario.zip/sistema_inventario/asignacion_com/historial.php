<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si se recibe el serial de la computadora
if (!isset($_GET['serial'])) {
    die("No se ha especificado una computadora.");
}

$serial_computadora = $_GET['serial'];

// Consulta SQL para obtener el historial de asignaciones de la computadora
$sql = "SELECT 
            ac.id AS id_asignacion,
            c.serial AS serie_computadora,
            c.modelo AS modelo_computadora,
            c.disco AS computadora_disco,
            c.ram AS computadora_ram,
            c.procesador AS computadora_procesador,
            c.sistema_operativo AS computadora_sistema_operativo,
            m.nombre AS marca_computadora,
            t.tipo AS tipo_computadora,
            u.usuario AS usuario,
            u.nombre AS nombre_usuario,
            u.telefono AS telefono_usuario,
            u.jefe_inmediato,
            u.puesto AS puesto_usuario,
            p.nombre AS nombre_planta,
            ac.fecha_asignacion,
            ac.asignado_por,
            ac.fecha_devolucion
        FROM asignaciones_computadora ac
        JOIN computadoras c ON ac.id_computadora = c.id
        JOIN usuarios u ON ac.id_usuario = u.usuario
        LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
        LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
        LEFT JOIN plantas p ON ac.planta = p.id  
        WHERE c.serial = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error en la consulta SQL: " . $conn->error);
}

$stmt->bind_param("s", $serial_computadora);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Asignaciones - <?= htmlspecialchars($serial_computadora) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end"></div>
    </header>

    <div class="container mt-4">
        <h2 class="mb-4">Historial de Asignaciones de la Computadora: <?= htmlspecialchars($serial_computadora) ?></h2>

        <a href="historial_asignaciones.php" class="btn btn-secondary mb-3">← Volver al Historial General</a>

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID Asignación</th>
                    <th>Usuario</th>
                    <th>Teléfono</th>
                    <th>Jefe Inmediato</th>
                    <th>Puesto</th>
                    <th>Planta</th>
                    <th>Fecha Asignación</th>
                    <th>Fecha Devolución</th>
                    <th>Asignado Por</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id_asignacion']) ?></td>
                        <td><?= htmlspecialchars($row['nombre_usuario']) ?></td>
                        <td><?= htmlspecialchars($row['telefono_usuario']) ?></td>
                        <td><?= htmlspecialchars($row['jefe_inmediato']) ?></td>
                        <td><?= htmlspecialchars($row['puesto_usuario']) ?></td>
                        <td><?= htmlspecialchars($row['nombre_planta']) ?></td>
                        <td><?= htmlspecialchars($row['fecha_asignacion']) ?></td>
                        <td><?= $row['fecha_devolucion'] ? htmlspecialchars($row['fecha_devolucion']) : 'En uso' ?></td>
                        <td><?= htmlspecialchars($row['asignado_por']) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
