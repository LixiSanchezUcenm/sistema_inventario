<?php
include '../conexion.php';
// menu header
include '../includes/header.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    die("Error: Usuario no autenticado.");
}

// Obtener usuario que asigna el componente
$usuario_asigna = $_SESSION['usuario'];

// Obtener componentes disponibles (no asignados y cuyo estado permite asignación)
$sql_componentes = "SELECT c.id, t.nombre AS tipo_componente, c.serial, c.modelo 
                    FROM componentes c
                    JOIN tipos_componentes t ON c.id_tipo = t.id
                    JOIN estados e ON c.estado_id = e.id
                    WHERE c.asignada = 0 
                    AND e.permite_asignacion = 1";

$result_componentes = $conn->query($sql_componentes);
$componentes = ($result_componentes->num_rows > 0) ? $result_componentes->fetch_all(MYSQLI_ASSOC) : [];

// Obtener computadoras disponibles (cuyo estado permite asignación)
$sql_computadoras = "SELECT c.id, c.serial, c.modelo 
                     FROM computadoras c
                     JOIN estados e ON c.estado_actual = e.id
                     WHERE e.permite_asignacion = 1";
$result_computadoras = $conn->query($sql_computadoras);
$computadoras = ($result_computadoras->num_rows > 0) ? $result_computadoras->fetch_all(MYSQLI_ASSOC) : [];

// Obtener plantas
$sql_plantas = "SELECT id, nombre FROM plantas";
$result_plantas = $conn->query($sql_plantas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Componente</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
	
	    
    <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
</head>
<body>

  <?php include '../includes/navbar.php'; ?>

  
  <div class="container mt-5">
    <h2>Asignar Componente a Computadora</h2>
    <form action="procesar_asignacion_componente.php" method="POST">
        <div class="mb-3">
            <label for="computadora" class="form-label">Computadora</label>
            <select class="form-select filtro" name="id_computadora" required>
                <option value="">Seleccione una computadora</option>
                <?php foreach ($computadoras as $row) { ?>
                    <option value="<?= $row['id']; ?>"><?= $row['serial']; ?> - <?= $row['modelo']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="componente" class="form-label">Componente</label>
            <select class="form-select filtro" name="id_componente" required>
                <option value="">Seleccione un componente</option>
                <?php foreach ($componentes as $row) { ?>
                    <option value="<?= $row['id']; ?>">(<?= $row['tipo_componente']; ?>) <?= $row['serial']; ?> - <?= $row['modelo']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="planta" class="form-label">Planta</label>
            <select class="form-select filtro" name="planta" required>
                <option value="">Seleccione una planta</option>
                <?php while ($row = $result_plantas->fetch_assoc()) { ?>
                    <option value="<?= $row['id']; ?>"><?= $row['nombre']; ?></option>
                <?php } ?>
            </select>
        </div>

        <input type="hidden" name="asignado_por" value="<?= $usuario_asigna; ?>">

        <button type="submit" class="btn btn-primary">Asignar</button>
    </form>
  </div>

  <script>
    $(document).ready(function() {
        $('.filtro').select2({
            width: '100%',
            placeholder: "Escriba para buscar...",
            allowClear: true
        });
    });
  </script>
</body>
</html>
