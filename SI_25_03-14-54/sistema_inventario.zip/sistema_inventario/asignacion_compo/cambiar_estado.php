<?php

include '../conexion.php';

// menu header
include '../includes/header.php';

if (!isset($_GET['id'])) {
    die('Error: ID de componente no especificado.');
}

$id_componente = $_GET['id'];

// Obtener el estado actual del componente
$query = "SELECT serial, estado_id FROM componentes WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_componente);
$stmt->execute();
$result = $stmt->get_result();
$componente = $result->fetch_assoc();

if (!$componente) {
    die('Error: Componente no encontrado.');
}

// Obtener lista de estados desde la base de datos
$query_estados = "SELECT id, nombre, permite_asignacion FROM estados";
$result_estados = $conn->query($query_estados);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar Estado de Componente</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <!-- Encabezado -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
    </header>

    <div class="container mt-5">
        <h2>Cambiar Estado de Componente - <?php echo $componente['serial']; ?></h2>
        <form action="procesar_cambio_componente.php" method="post">
            <input type="hidden" name="id" value="<?php echo $id_componente; ?>">

            <div class="mb-3">
                <label for="estado" class="form-label">Nuevo Estado:</label>
                <select name="estado" id="estado" class="form-control" required>
                    <?php while ($row = $result_estados->fetch_assoc()) { ?>
                        <option value="<?= $row['id']; ?>" <?= ($row['id'] == $componente['estado_id']) ? 'selected' : ''; ?>>
                            <?= $row['nombre']; ?> <?= ($row['permite_asignacion'] == 1) ? "(Asignable)" : "(No asignable)"; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="comentario" class="form-label">Comentario (opcional):</label>
                <textarea name="comentario" id="comentario" class="form-control"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="listar_componentes.php" class="btn btn-secondary">Volver</a>
        </form>
    </div>

</body>
</html>
