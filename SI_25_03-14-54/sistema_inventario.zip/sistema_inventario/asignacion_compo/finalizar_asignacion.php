<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_asignacion'])) {
    $id_asignacion = $_POST['id_asignacion'];
    $fecha_actual = date("Y-m-d H:i:s");

    // Obtener el ID del componente asignado
    $sql_get_componentes = "SELECT id_componente FROM asignaciones_componentes WHERE id = ?";
    $stmt = $conn->prepare($sql_get_componentes);
    $stmt->bind_param("i", $id_asignacion);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_componente = $row['id_componente']; // Cambio de variable a singular

        // Finalizar la asignación del componente
        $sql_update_asignacion = "UPDATE asignaciones_componentes SET activo = 0, fecha_devolucion = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update_asignacion);
        $stmt->bind_param("si", $fecha_actual, $id_asignacion);

        if ($stmt->execute()) {
            // Actualizar el estado del componente para indicar que ya no está asignado
            $sql_update_componente = "UPDATE componentes SET asignada = 0, ubicacion = 'Almacén IT' WHERE id = ?";
            $stmt = $conn->prepare($sql_update_componente);
            $stmt->bind_param("i", $id_componente);

            if ($stmt->execute()) {
                echo "<script>alert('Asignación de componente finalizada correctamente'); window.location.href='historial_asignaciones.php';</script>";
            } else {
                echo "<script>alert('Error al actualizar el componente: " . $stmt->error . "'); window.location.href='historial_asignaciones.php';</script>";
            }
        } else {
            echo "<script>alert('Error al finalizar la asignación de componente: " . $stmt->error . "'); window.location.href='historial_asignaciones.php';</script>";
        }
    } else {
        echo "<script>alert('No se encontró el componente asociado'); window.location.href='historial_asignaciones.php';</script>";
    }

    $conn->close();
} else {
    echo "<script>alert('Solicitud no válida'); window.location.href='historial_asignaciones.php';</script>";
}

?>
