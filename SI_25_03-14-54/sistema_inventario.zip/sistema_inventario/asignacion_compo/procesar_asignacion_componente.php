<?php
include '../conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_computadora = isset($_POST['id_computadora']) ? $_POST['id_computadora'] : null;
$id_componente = isset($_POST['id_componente']) ? $_POST['id_componente'] : null;
$planta = isset($_POST['planta']) ? $_POST['planta'] : null;
$asignado_por = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : 'Desconocido';

    $fecha_asignacion = date('Y-m-d H:i:s');

    if (!$id_computadora || !$id_componente || !$planta) {
        die("Error: Todos los campos son obligatorios.");
    }

    $conn->begin_transaction();
    try {
        // Insertar en la tabla de asignaciones
        $sql_asignar = "INSERT INTO asignaciones_componentes (id_computadora, id_componente, planta, asignado_por, fecha_asignacion, activo) VALUES (?, ?, ?, ?, ?, 1)";
        $stmt = $conn->prepare($sql_asignar);
        $stmt->bind_param("iisss", $id_computadora, $id_componente, $planta, $asignado_por, $fecha_asignacion);
        $stmt->execute();

        if ($stmt->affected_rows <= 0) {
            throw new Exception("Error: No se pudo asignar el componente.");
        }

        // Actualizar el componente como asignado y cambiar su ubicación
        $sql_update_componente = "UPDATE componentes SET asignada = 1, ubicacion = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update_componente);
        $stmt->bind_param("si", $planta, $id_componente);
        $stmt->execute();

		
		
        if ($stmt->affected_rows <= 0) {
            throw new Exception("Error: No se pudo actualizar el componente.");
        }

        $conn->commit();
       echo "<script>alert('Asignada correctamente.'); window.location.href='asignacion_componentes.php';</script>";
    exit();
		
    } catch (Exception $e) {
        $conn->rollback();
        echo $e->getMessage();
    }
} else {
    die("Acceso denegado.");
	
}
?>
