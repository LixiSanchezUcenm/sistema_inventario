<?php
session_start();
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_componente = $_POST['id'];
    $nuevo_estado = $_POST['estado'];
    $comentario = isset($_POST['comentario']) ? $_POST['comentario'] : ''; // Si no hay comentario, es una cadena vacía
    $usuario = $_SESSION['usuario'];

    // Actualizar el estado del componente
    $query = "UPDATE componentes SET estado_id = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $nuevo_estado, $id_componente);  // Asegúrate de que el tipo de dato sea correcto
    $stmt->execute();

    // Guardar el historial
    $query_historial = "INSERT INTO historial_estados_componentes (serial, nuevo_estado, comentario, usuario) 
                        VALUES ((SELECT serial FROM componentes WHERE id = ?), ?, ?, ?)";
    $stmt_historial = $conn->prepare($query_historial);
    $stmt_historial->bind_param("isss", $id_componente, $nuevo_estado, $comentario, $usuario);  // Asegúrate de que las variables coincidan con los tipos

    if ($stmt_historial->execute()) {
        header("Location: listar_componentes.php");
        exit();
    } else {
        echo "Error al guardar el historial: " . $stmt_historial->error;
    }
}


?>
