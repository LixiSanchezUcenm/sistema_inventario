<?php
include '../conexion.php';
include '../includes/header.php';

// Obtener dispositivos (componentes) con su estado actual y tipo de componente
$query = "SELECT c.id, c.serial, e.nombre AS estado_actual, t.nombre AS tipo_componente
          FROM componentes c
          JOIN estados e ON c.estado_id = e.id
          JOIN tipos_componentes t ON c.id_tipo = t.id";
$resultado = mysqli_query($conn, $query);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conn));
}

// Obtener todos los tipos de componentes para el filtro
$query_tipos = "SELECT * FROM tipos_componentes";
$resultado_tipos = mysqli_query($conn, $query_tipos);
if (!$resultado_tipos) {
    die("Error al obtener tipos de componentes: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Dispositivos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
    <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container mt-5">
        <h2>Lista de Dispositivos</h2>
        
        <!-- Filtros -->
        <div class="row mb-3">
            <div class="col-md-6">
                <select id="tipoComponenteFilter" class="form-select" onchange="filtrarTabla()">
                    <option value="">Todos los Tipos</option>
                    <?php while ($tipo = mysqli_fetch_assoc($resultado_tipos)): ?>
                        <option value="<?php echo $tipo['nombre']; ?>"><?php echo $tipo['nombre']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-6">
                <input type="text" id="searchInput" class="form-control" placeholder="Buscar por ID, Tipo de Componente, Serial o Estado..." onkeyup="filtrarTabla()">
            </div>
        </div>
        
        <table class="table table-bordered" id="dispositivosTable">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Tipo de Componente</th>
                    <th>Serial</th>
                    <th>Estado Actual</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($dispositivo = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?php echo $dispositivo['id']; ?></td>
                    <td><?php echo $dispositivo['tipo_componente']; ?></td>
                    <td><?php echo $dispositivo['serial']; ?></td>
                    <td>
                        <span class="badge bg-<?php echo getColorEstado($dispositivo['estado_actual']); ?>">
                            <?php echo ucfirst($dispositivo['estado_actual']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="cambiar_estado.php?id=<?php echo $dispositivo['id']; ?>" class="btn btn-warning btn-sm">Cambiar Estado</a>
                        <a href="ver_historial.php?id=<?php echo $dispositivo['id']; ?>" class="btn btn-info btn-sm">Ver Historial</a> <!-- Botón de historial -->
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function filtrarTabla() {
            var input = document.getElementById("searchInput").value.toLowerCase();
            var tipoComponenteFilter = document.getElementById("tipoComponenteFilter").value.toLowerCase();
            var tabla = document.getElementById("dispositivosTable");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) {
                var celdas = filas[i].getElementsByTagName("td");
                var mostrar = false;
                
                var id = celdas[0].textContent.toLowerCase();
                var tipoComponente = celdas[1].textContent.toLowerCase();
                var serial = celdas[2].textContent.toLowerCase();
                var estado = celdas[3].textContent.toLowerCase();

                if ((id.includes(input) || tipoComponente.includes(input) || serial.includes(input) || estado.includes(input)) &&
                    (tipoComponenteFilter === "" || tipoComponente.includes(tipoComponenteFilter))) {
                    mostrar = true;
                }

                filas[i].style.display = mostrar ? "" : "none";
            }
        }
    </script>
</body>
</html>

<?php
// Función para definir los colores según el estado
function getColorEstado($estado) {
    switch ($estado) {
        case 'buena': return 'success';
        case 'mantenimiento': return 'warning';
        case 'robada': return 'danger';
        case 'obsoleta': return 'secondary';
        default: return 'dark';
    }
}
?>
