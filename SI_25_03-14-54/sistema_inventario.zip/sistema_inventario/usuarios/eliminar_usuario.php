<?php
session_start();
include '../conexion.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Eliminar usuario
if (isset($_GET['usuario'])) {
    $usuario = $_GET['usuario'];
    $query = "DELETE FROM Usuarios WHERE usuario = '$usuario'";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Usuario eliminado con éxito'); window.location.href='usuarios.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar usuario');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2 class="text-center text-danger">Eliminar Usuario</h2>
    <p class="text-center">¿Estás seguro de que deseas eliminar este usuario? Esta acción no se puede deshacer.</p>
    <form method="GET" class="text-center">
        <input type="hidden" name="usuario" value="<?php echo $_GET['usuario']; ?>">
        <button type="submit" class="btn btn-danger">Eliminar</button>
        <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>