<?php

include '../conexion.php';

// menu header
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $nombre = $_POST['nombre'];
    $contrasena = !empty($_POST['contrasena']) ? password_hash($_POST['contrasena'], PASSWORD_DEFAULT) : null;
    $rol = $_POST['rol'];
    $puesto = $_POST['puesto'];
    $telefono = $_POST['telefono'];
    $imei = $_POST['imei'];
    $jefe = $_POST['jefe_inmediato'];
    $departamento_id = $_POST['departamento']; // Departamento seleccionado
    $planta = $_POST['planta']; // Planta seleccionada

    // Verificar si el usuario ya existe
    $check_query = "SELECT * FROM Usuarios WHERE usuario = '$usuario'";
    $check_result = mysqli_query($conn, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('El usuario ya existe');</script>";
    } else {
        // Insertar nuevo usuario con planta y departamento
        $query = "INSERT INTO Usuarios (usuario, nombre, contrasena, rol, puesto, telefono, IMEI, jefe_inmediato, departamento_id, planta) 
                  VALUES ('$usuario', '$nombre', " . ($contrasena ? "'$contrasena'" : "NULL") . ", '$rol', '$puesto', '$telefono', '$imei', '$jefe', '$departamento_id', '$planta')";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Usuario creado con éxito'); window.location.href='usuarios.php';</script>";
        } else {
            echo "<script>alert('Error al crear usuario');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1>
        <div class="user-info text-end"></div>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Agregar Nuevo Usuario</h2>
        <form method="POST" class="mt-3">
            <div class="mb-3">
                <label class="form-label">Usuario:</label>
                <input type="text" name="usuario" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Nombre:</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña (opcional):</label>
                <input type="password" name="contrasena" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">Rol:</label>
                <select name="rol" class="form-control">
                    <option value="usuario">Usuario</option>
                    <option value="administrador">Administrador</option>
                    <option value="sin acceso">Sin Acceso</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Puesto:</label>
                <input type="text" name="puesto" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Teléfono:</label>
                <input type="text" name="telefono" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">IMEI:</label>
                <input type="text" name="imei" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">Jefe Inmediato:</label>
                <input type="text" name="jefe_inmediato" class="form-control">
            </div>

            <!-- Campo de selección de departamento -->
            <div class="mb-3">
                <label class="form-label">Departamento:</label>
                <select name="departamento" class="form-control" required>
                    <option value="">Seleccionar Departamento</option>
                    <?php
                    // Obtener lista de departamentos
                    $departamentos_query = "SELECT * FROM Departamentos";
                    $departamentos_result = mysqli_query($conn, $departamentos_query);
                    while ($row = mysqli_fetch_assoc($departamentos_result)) {
                        echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Campo de selección de planta -->
            <div class="mb-3">
                <label class="form-label">Planta:</label>
                <select name="planta" class="form-control" required>
                    <option value="">Seleccionar Planta</option>
                    <?php
                    // Obtener lista de plantas
                    $plantas_query = "SELECT * FROM Plantas";
                    $plantas_result = mysqli_query($conn, $plantas_query);
                    while ($row = mysqli_fetch_assoc($plantas_result)) {
                        echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Guardar Usuario</button>
            <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
