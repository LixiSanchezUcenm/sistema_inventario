<?php

include '../conexion.php';

// menu header
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Obtener datos del usuario a editar
if (isset($_GET['usuario'])) {
    $usuario = $_GET['usuario'];
    $query = "SELECT * FROM Usuarios WHERE usuario = '$usuario'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);
}

// Obtener lista de departamentos
$departamentos_query = "SELECT * FROM Departamentos";
$departamentos_result = mysqli_query($conn, $departamentos_query);

// Obtener lista de plantas
$plantas_query = "SELECT * FROM Plantas";
$plantas_result = mysqli_query($conn, $plantas_query);

// Procesar el formulario de actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $nombre = $_POST['nombre'];
    $rol = $_POST['rol'];
    $puesto = $_POST['puesto'];
    $telefono = $_POST['telefono'];
    $imei = $_POST['imei'];
    $jefe = $_POST['jefe_inmediato'];
    $departamento_id = $_POST['departamento']; // Usamos departamento_id para la actualización
    $planta = $_POST['planta']; // Usamos planta para la actualización

    $query = "UPDATE Usuarios SET 
                nombre='$nombre', 
                rol='$rol', 
                puesto='$puesto', 
                telefono='$telefono', 
                IMEI='$imei', 
                jefe_inmediato='$jefe', 
                departamento_id='$departamento_id',  
                planta='$planta' 
              WHERE usuario='$usuario'";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Usuario actualizado con éxito'); window.location.href='usuarios.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar usuario');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>

    <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>

<body>
    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end"></div>
    </header>

    <div class="container mt-4">
        <h2 class="text-center">Editar Usuario</h2>
        <form method="POST" class="mt-3">
            <input type="hidden" name="usuario" value="<?php echo $user['usuario']; ?>">
            
            <div class="mb-3">
                <label class="form-label">Nombre:</label>
                <input type="text" name="nombre" class="form-control" value="<?php echo $user['nombre']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Rol:</label>
                <select name="rol" class="form-control">
                    <option value="usuario" <?php if ($user['rol'] == 'usuario') echo 'selected'; ?>>Usuario</option>
                    <option value="administrador" <?php if ($user['rol'] == 'administrador') echo 'selected'; ?>>Administrador</option>
                    <option value="sin acceso" <?php if ($user['rol'] == 'sin acceso') echo 'selected'; ?>>Sin Acceso</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Puesto:</label>
                <input type="text" name="puesto" class="form-control" value="<?php echo $user['puesto']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Teléfono:</label>
                <input type="text" name="telefono" class="form-control" value="<?php echo $user['telefono']; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">IMEI:</label>
                <input type="text" name="imei" class="form-control" value="<?php echo $user['IMEI']; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Jefe Inmediato:</label>
                <input type="text" name="jefe_inmediato" class="form-control" value="<?php echo $user['jefe_inmediato']; ?>">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Departamento:</label>
                <select name="departamento" class="form-control" required>
                    <option value="">Seleccionar Departamento</option>
                    <?php while ($row = mysqli_fetch_assoc($departamentos_result)) { ?>
                        <option value="<?php echo $row['id']; ?>" <?php if ($user['departamento_id'] == $row['id']) echo 'selected'; ?>>
                            <?php echo $row['nombre']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Planta:</label>
                <select name="planta" class="form-control" required>
                    <option value="">Seleccionar Planta</option>
                    <?php while ($row = mysqli_fetch_assoc($plantas_result)) { ?>
                        <option value="<?php echo $row['id']; ?>" <?php if ($user['planta'] == $row['id']) echo 'selected'; ?>>
                            <?php echo $row['nombre']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
            <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
