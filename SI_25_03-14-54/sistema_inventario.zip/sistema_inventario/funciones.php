<?php
session_start();
include 'conexion.php';

// Función para verificar permisos
function verificar_acceso($roles_permitidos) {
    if (!isset($_SESSION['rol']) || !in_array($_SESSION['rol'], $roles_permitidos)) {
        header("Location: acceso_denegado.php");
        exit();
    }
}
?>
