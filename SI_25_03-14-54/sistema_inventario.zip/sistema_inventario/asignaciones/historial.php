<?php
include '../conexion.php';


// menu header
include '../includes/header.php';


// Verificar si se recibe el serial de la impresora
if (!isset($_GET['serial'])) {
    die("No se ha especificado una impresora.");
}

$serial_impresora = $_GET['serial'];

// Consulta SQL para obtener todas las asignaciones de la impresora seleccionada
$sql = "SELECT 
            a.id AS id_asignacion,
            u.nombre AS nombre_usuario, 
            u.telefono AS telefono_usuario, 
            u.jefe_inmediato, 
            u.puesto, 
            i.serial AS serie_impresora, 
            i.modelo AS modelo_impresora, 
            m.nombre AS marca_impresora, 
            t.tipo AS tipo_impresora, 
            p.PDV, 
            p.descripcion AS nombre_pdv, 
            a.fecha_asignacion, 
            a.fecha_devolucion,
            a.asignado_por 
        FROM Asignaciones a
        JOIN Usuarios u ON a.usuario = u.usuario
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Marcas m ON i.id_marca = m.id
        JOIN Tipos_Impresoras t ON i.id_tipo = t.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        WHERE i.serial = ?
        ORDER BY a.fecha_asignacion DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $serial_impresora);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Asignaciones - <?= htmlspecialchars($serial_impresora) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	
		
			 <!-- Menu header -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
	
</head>
	
<body >
	
	<!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>
	
	<div class="container mt-4">
        <h2 class="mb-4">Historial de Asignaciones de la Impresora: <?= htmlspecialchars($serial_impresora) ?></h2>

        <a href="historial_asignaciones.php" class="btn btn-secondary mb-3">← Volver al Historial General</a>

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID Asignación</th>
                    <th>Usuario</th>
                    <th>Teléfono</th>
                    <th>Jefe Inmediato</th>
                    <th>Puesto</th>
                    <th>Punto de Venta</th>
                    <th>Descripción PDV</th>
                    <th>Fecha Asignación</th>
                    <th>Fecha Devolución</th>
                    <th>Asignado Por</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id_asignacion']) ?></td>
                        <td><?= htmlspecialchars($row['nombre_usuario']) ?></td>
                        <td><?= htmlspecialchars($row['telefono_usuario']) ?></td>
                        <td><?= htmlspecialchars($row['jefe_inmediato']) ?></td>
                        <td><?= htmlspecialchars($row['puesto']) ?></td>
                        <td><?= htmlspecialchars($row['PDV']) ?></td>
                        <td><?= htmlspecialchars($row['nombre_pdv']) ?></td>
                        <td><?= htmlspecialchars($row['fecha_asignacion']) ?></td>
                        <td><?= $row['fecha_devolucion'] ? htmlspecialchars($row['fecha_devolucion']) : 'En uso' ?></td>
                        <td><?= htmlspecialchars($row['asignado_por']) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
