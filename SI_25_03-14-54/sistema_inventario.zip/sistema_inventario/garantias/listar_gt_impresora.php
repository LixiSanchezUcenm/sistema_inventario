<?php
include '../conexion.php';
include '../includes/header.php';

// Asegurar la zona horaria correcta
date_default_timezone_set('America/Mexico_City');

$query = "SELECT id, serial, modelo, fecha_compra, fecha_vencimiento_garantia, proveedor_garantia, estado_garantia FROM Impresoras";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Garantías</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
</head>
<body>
	    <?php include '../includes/navbar.php'; ?>

	

<div class="container mt-5">
    <h2 class="text-center text-primary">Lista de Garantías</h2>

    <!-- Filtros para cada columna -->
    <div class="mb-3">
        <input type="text" id="filtro" class="form-control" placeholder="Buscar en cualquier columna...">
    </div>

    <table class="table table-striped table-bordered" id="tablaGarantias">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Serial</th>
                <th>Modelo</th>
                <th>Fecha de Compra</th>
                <th>Fecha Vencimiento</th>
                <th>Proveedor</th>
                <th>Factura Garantía</th>
                <th>Tiempo Restante</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            include '../conexion.php';
            date_default_timezone_set('America/Mexico_City');

            $query = "SELECT id, serial, modelo, fecha_compra, fecha_vencimiento_garantia, proveedor_garantia, N_garantia FROM Impresoras";
            $result = $conn->query($query);

            while ($row = $result->fetch_assoc()) { 
                $hoy = strtotime(date('Y-m-d')); 
                $vencimiento = strtotime($row['fecha_vencimiento_garantia']);
                $dias_restantes = floor(($vencimiento - $hoy) / 86400);

                $texto_garantia = ($dias_restantes < 0) 
                    ? "<span class='text-danger'>Expirada hace " . abs($dias_restantes) . " días</span>" 
                    : "<span class='text-success'>" . $dias_restantes . " días restantes</span>";
            ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['serial']; ?></td>
                <td><?php echo $row['modelo']; ?></td>
                <td><?php echo $row['fecha_compra']; ?></td>
                <td><?php echo $row['fecha_vencimiento_garantia']; ?></td>
                <td><?php echo $row['proveedor_garantia']; ?></td>
                <td><?php echo $row['N_garantia']; ?></td>
                <td><?php echo $texto_garantia; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
        $("#filtro").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#tablaGarantias tbody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });
    });
</script>

</body>
</html>

