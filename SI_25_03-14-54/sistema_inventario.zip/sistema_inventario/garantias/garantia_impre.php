<?php
include '../conexion.php';
include '../includes/header.php';

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

$id = $_GET['id'];

$query = "SELECT fecha_compra, fecha_vencimiento_garantia, proveedor_garantia, N_garantia FROM Impresoras WHERE id = $id";
$result = mysqli_query($conn, $query);
$impresora = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha_compra = $_POST['fecha_compra'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $N_garantia = $_POST['N_garantia'];
    $proveedor = $_POST['proveedor'];

    $update_query = "UPDATE Impresoras SET 
                     fecha_compra = '$fecha_compra', 
                     fecha_vencimiento_garantia = '$fecha_vencimiento', 
                     proveedor_garantia = '$proveedor',
                     N_garantia = '$N_garantia' 
                     WHERE id = $id";

    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Garantía actualizada correctamente'); window.location.href='../admin/crud_impresoras.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar la garantía'); window.location.href='../admin/crud_impresoras.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Garantía</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">Editar Garantía de Impresora</h2>
        <form method="POST">
            <div class="mb-3">
                <label for="fecha_compra" class="form-label">Fecha de Compra</label>
                <input type="date" class="form-control" id="fecha_compra" name="fecha_compra" value="<?php echo $impresora['fecha_compra']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="fecha_vencimiento" class="form-label">Fecha de Vencimiento de Garantía</label>
                <input type="date" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento" value="<?php echo $impresora['fecha_vencimiento_garantia']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="N_garantia" class="form-label">Número de Garantía</label>
                <input type="text" class="form-control" id="N_garantia" name="N_garantia" value="<?php echo $impresora['N_garantia']; ?>" required>
            </div> 

            <div class="mb-3">
                <label for="proveedor" class="form-label">Proveedor</label>
           <input type="text" class="form-control" id="proveedor" name="proveedor" value="<?php echo $impresora['proveedor_garantia']; ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="../admin/crud_impresoras.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

</body>
</html>
