<?php
include '../conexion.php';

include '../includes/header.php';

// Obtener los estados dinámicamente
$estados_query = "SELECT DISTINCT estado_actual FROM impresoras";
$estados_resultado = mysqli_query($conn, $estados_query);
$estados = [];
while ($fila = mysqli_fetch_assoc($estados_resultado)) {
    $estados[] = $fila['estado_actual'];
}

// Obtener las plantas con PDVs
$plantas_query = "SELECT DISTINCT p.nombre AS planta FROM plantas p
LEFT JOIN puntos_venta pv ON p.id = pv.id_planta";
$plantas_resultado = mysqli_query($conn, $plantas_query);
$plantas = ['Almacén IT']; // Agregar "Almacén IT" al listado de plantas
while ($fila = mysqli_fetch_assoc($plantas_resultado)) {
    $plantas[] = $fila['planta'];
}

// Obtener el conteo de impresoras por estado y planta
date_default_timezone_set('America/Mexico_City');
$conteo = [];
$sql = "SELECT p.nombre AS planta, i.estado_actual, COUNT(*) AS cantidad
        FROM impresoras i
        LEFT JOIN asignaciones a ON i.id = a.id_impresora AND a.activo = 1
        LEFT JOIN puntos_venta pv ON a.PDV = pv.PDV
        LEFT JOIN plantas p ON pv.id_planta = p.id
        GROUP BY p.nombre, i.estado_actual";

$resultado = mysqli_query($conn, $sql);

if ($resultado) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $planta = isset($fila['planta']) ? $fila['planta'] : 'Almacén IT';
        $estado = $fila['estado_actual'];
        $conteo[$planta][$estado] = $fila['cantidad'];
    }
} else {
    die("Error en la consulta: " . mysqli_error($conn));
}



// Obtener el total por estado desde la vista
$sql_estados = "SELECT estado_actual, total FROM conteo_impresoras";
$result_estados = mysqli_query($conn, $sql_estados);
$conteo_estados = [];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $conteo_estados[$row['estado_actual']] = $row['total'];
}

// Obtener el total general de impresoras
$sql_total = "SELECT SUM(total) AS total_general FROM conteo_impresoras";
$result_total = mysqli_query($conn, $sql_total);
$total_general = mysqli_fetch_assoc($result_total)['total_general'];



mysqli_close($conn);
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Conteo de Impresoras</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	
				 <!-- Menu header -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
</head>
	
	
<body >
	
	    <?php include '../includes/navbar.php'; ?>

	
	<div class="container mt-4">
	
				
			    
    <div class="container mt-4">
        <div class="text-center my-3">
            <a href="conteo_impresoras.php" class="btn btn-primary">Estado</a>
            <a href="conteo_tipo.php" class="btn btn-primary">Tipo por planta</a>

        </div>

		

		
		 <h2 class="text-center mb-4">📊 Conteo de Impresoras </h2>




            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th>Estado</th>
                        <?php foreach ($conteo_estados as $estado => $cantidad) { ?>
                            <th><?php echo ucfirst($estado); ?></th>
                        <?php } ?>
                        <th>Total General</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Cantidad</td>
                        <?php foreach ($conteo_estados as $cantidad) { ?>
                            <td><?php echo $cantidad; ?></td>
                        <?php } ?>
                        <td id="total-general"><?php echo $total_general; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function actualizarConteo() {
            $.ajax({
                url: "conteo_impresoras_ajax.php",
                method: "GET",
                success: function(response) {
                    let datos = JSON.parse(response);
                    let estadosHtml = "";
                    let cantidadesHtml = "<td>Cantidad</td>";
                    let totalGeneral = 0;

                    datos.forEach(row => {
                        estadosHtml += `<th>${row.estado_actual.charAt(0).toUpperCase() + row.estado_actual.slice(1)}</th>`;
                        cantidadesHtml += `<td>${row.total}</td>`;
                        totalGeneral += parseInt(row.total);
                    });

                    $(".table thead tr").html("<th>Estado</th>" + estadosHtml + "<th>Total General</th>");
                    $(".table tbody tr").html(cantidadesHtml + `<td id='total-general'>${totalGeneral}</td>`);
                }
            });
        }
    </script>

 </div>
    
	
    <div class="container mt-4">
		

        <h2 class="text-center">📊 Conteo de Impresoras por Planta</h2>
       
	
	
	
        <!-- Selector de Planta -->
        <div class="mb-3">
            <label for="filtroPlanta" class="form-label">Selecciona una Planta:</label>
            <select id="filtroPlanta" class="form-select">
                <option value="Todas">Todas</option>
                <?php foreach ($plantas as $planta) { ?>
                    <option value="<?php echo $planta; ?>"><?php echo $planta; ?></option>
                <?php } ?>
            </select>
        </div>
        
        <!-- Tabla de Conteo -->
        <table class="table table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>Planta</th>
                    <?php foreach ($estados as $estado) { ?>
                        <th><?php echo ucfirst($estado); ?></th>
                    <?php } ?>
                </tr>
            </thead>
            <tbody id="tablaConteo">
                <?php foreach ($conteo as $planta => $datos) { ?>
                    <tr>
                        <td><strong><?php echo $planta; ?></strong></td>
                        <?php foreach ($estados as $estado) { ?>
                            <td><?php echo isset($datos[$estado]) ? $datos[$estado] : 0; ?></td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        
        <!-- Gráfico Circular -->
        <div class="d-flex justify-content-center">
            <canvas id="graficoImpresoras" style="max-width: 400px; height: 300px;"></canvas>
        </div>
    </div>
    
    <script>
        const conteo = <?php echo json_encode($conteo); ?>;
        let ctx = document.getElementById('graficoImpresoras').getContext('2d');

        function getDataForChart(planta) {
            let estados = <?php echo json_encode($estados); ?>;
            let data = estados.map(estado => planta === "Todas" ? 
                Object.values(conteo).reduce((sum, p) => sum + (p[estado] || 0), 0) :
                (conteo[planta]?.[estado] || 0)
            );
            return { estados, data };
        }

        let { estados, data } = getDataForChart("Todas");
        let chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: estados,
                datasets: [{
                    data: data,
                    backgroundColor: estados.map((_, i) => `hsl(${i * 60}, 70%, 50%)`)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Distribución de Impresoras' }
                }
            }
        });

        document.getElementById("filtroPlanta").addEventListener("change", function () {
            let plantaSeleccionada = this.value;
            let { estados, data } = getDataForChart(plantaSeleccionada);

            let tablaHTML = "";
            for (let planta in conteo) {
                if (plantaSeleccionada === "Todas" || planta === plantaSeleccionada) {
                    tablaHTML += `<tr>
                        <td><strong>${planta}</strong></td>
                        ${estados.map(e => `<td>${conteo[planta]?.[e] || 0}</td>`).join('')}
                    </tr>`;
                }
            }
            document.getElementById("tablaConteo").innerHTML = tablaHTML;

            chart.data.datasets[0].data = data;
            chart.update();
        });
    </script>
</body>
</html>
