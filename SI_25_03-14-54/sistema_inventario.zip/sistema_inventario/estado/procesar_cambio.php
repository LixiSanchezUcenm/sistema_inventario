<?php
session_start();
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_impresora = $_POST['id'];
    $nuevo_estado = $_POST['estado'];
$comentario = isset($_POST['comentario']) ? $_POST['comentario'] : '';
    $usuario = $_SESSION['usuario'];

    // Actualizar el estado
    $query = "UPDATE impresoras SET estado_actual = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $nuevo_estado, $id_impresora);
    $stmt->execute();

    // Guardar en historial
    $query_historial = "INSERT INTO historial_estados (serial, nuevo_estado, comentario, usuario) VALUES ((SELECT serial FROM impresoras WHERE id = ?), ?, ?, ?)";
    $stmt_historial = $conn->prepare($query_historial);
    $stmt_historial->bind_param("isss", $id_impresora, $nuevo_estado, $comentario, $usuario);
    $stmt_historial->execute();

    header("Location: listar_impresoras.php");
    exit();
}
?>
