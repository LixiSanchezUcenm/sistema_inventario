<?php
include '../conexion.php';


include '../includes/header.php';


// Agregar estado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $permite_asignacion = isset($_POST['permite_asignacion']) ? 1 : 0;

    $query = "INSERT INTO estados (nombre, permite_asignacion) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "si", $nombre, $permite_asignacion);
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Estado agregado exitosamente'); window.location.href='listar_impresoras.php';</script>";
    } else {
        echo "<script>alert('Error al agregar estado'); window.location.href='listar_impresoras.php';</script>";
    }
    mysqli_stmt_close($stmt);
}

// Editar estado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $permite_asignacion = isset($_POST['permite_asignacion']) ? 1 : 0;

    $query = "UPDATE estados SET nombre = ?, permite_asignacion = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sii", $nombre, $permite_asignacion, $id);
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Estado actualizado exitosamente'); window.location.href='listar_impresoras.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar estado'); window.location.href='listar_impresoras.php';</script>";
    }
    mysqli_stmt_close($stmt);
}

// Eliminar estado
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $query = "DELETE FROM estados WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Estado eliminado exitosamente'); window.location.href='listar_impresoras.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar estado'); window.location.href='listar_impresoras.php';</script>";
    }
    mysqli_stmt_close($stmt);
}

// Obtener lista de estados
$query = "SELECT * FROM estados";
$resultado = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Estados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	
					 <!-- Menu header -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
	
	
</head>
	
<body >
	
	<!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>
	
	<div class="container mt-4">
	
		
    <h2 class="text-center">Gestión de Estados</h2>
		
		        <a href="listar_impresoras.php" class="btn btn-secondary">Volver</a>


    <!-- Formulario de Agregar Estado -->
    <form action="" method="POST" class="mb-3">
        <div class="input-group">
            <input type="text" name="nombre" class="form-control" placeholder="Nombre del estado" required>
            <div class="input-group-text">
                <input type="checkbox" name="permite_asignacion"> Permite Asignación
            </div>
            <button type="submit" name="agregar" class="btn btn-primary">Agregar</button>
        </div>
    </form>

    <!-- Tabla de Estados -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Estado</th>
                <th>Permite Asignación</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($estado = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?= $estado['nombre'] ?></td>
                    <td><?= $estado['permite_asignacion'] ? 'Sí' : 'No' ?></td>
                    <td>
                        <!-- Formulario de Edición -->
                        <form action="" method="POST" class="d-inline">
                            <input type="hidden" name="id" value="<?= $estado['id'] ?>">
                            <input type="text" name="nombre" value="<?= $estado['nombre'] ?>" required>
                            <input type="checkbox" name="permite_asignacion" <?= $estado['permite_asignacion'] ? 'checked' : '' ?>>
                            <button type="submit" name="editar" class="btn btn-warning btn-sm">Editar</button>
                        </form>

                        <!-- Botón de Eliminar -->
                        <a href="?eliminar=<?= $estado['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este estado?')">Eliminar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
