<?php 
include '../conexion.php';
include '../includes/header.php';
$sql = "SELECT 
            pl.nombre AS nombre_planta,
            t.tipo AS tipo_impresora,
            COUNT(a.id) AS cantidad_asignaciones
        FROM Asignaciones a
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Tipos_Impresoras t ON i.id_tipo = t.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        JOIN Plantas pl ON p.id_planta = pl.id
        WHERE a.activo = 1
        GROUP BY pl.nombre, t.tipo
        ORDER BY pl.nombre, cantidad_asignaciones DESC";

$result = $conn->query($sql);

$datos = [];
$tiposImpresoras = [];

while ($row = $result->fetch_assoc()) {
    $planta = $row['nombre_planta'];
    $tipo = $row['tipo_impresora'];
    $cantidad = $row['cantidad_asignaciones'];

    $datos[$planta][$tipo] = $cantidad;

    if (!in_array($tipo, $tiposImpresoras)) {
        $tiposImpresoras[] = $tipo;
    }
}

$conn->close();

$plantas = array_keys($datos);
$colores = ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#A133FF', '#33FFF5'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignaciones por Planta</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	
	    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <link rel="stylesheet" href="../styles.css">
    
	
</head>
<body>
    
    <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>
    
    <div class="container mt-4">
		
				
			    
    <div class="container mt-4">
        <div class="text-center my-3">
            <a href="conteo_impresoras.php" class="btn btn-primary">Estado</a>
            <a href="conteo_tipo.php" class="btn btn-primary">Tipo por planta</a>

        </div>

		


        <h3 class="text-center mb-4">Asignaciones de Impresoras por Tipo</h3>

		
		
        <!-- Filtro de Planta -->
        <div class="mb-3">
            <label for="filtroPlanta" class="form-label">Filtrar por Planta:</label>
            <select id="filtroPlanta" class="form-select">
                <option value="Todas">Todas</option>
                <?php foreach ($plantas as $planta): ?>
                    <option value="<?php echo $planta; ?>"><?php echo $planta; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Tabla de Datos -->
        <table class="table table-striped mt-4">
            <thead>
                <tr>
                    <th>Planta</th>
                    <?php foreach ($tiposImpresoras as $tipo): ?>
                        <th><?php echo $tipo; ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($datos as $planta => $valores): ?>
                    <tr>
                        <td><?php echo $planta; ?></td>
                        <?php foreach ($tiposImpresoras as $tipo): ?>
                            <td><?php echo isset($valores[$tipo]) ? $valores[$tipo] : 0; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Gráfico -->
        <div class="d-flex justify-content-center mt-4">
            <canvas id="graficoAsignaciones" style="max-width: 500px; max-height: 300px;"></canvas>
        </div>
    </div>

    <script>
        var datosPlantas = <?php echo json_encode($datos); ?>;
        var tiposImpresoras = <?php echo json_encode($tiposImpresoras); ?>;
        var colores = <?php echo json_encode($colores); ?>;

        function obtenerDatosPlanta(plantaSeleccionada) {
            let labels = [];
            let data = [];

            if (plantaSeleccionada === "Todas") {
                labels = Object.keys(datosPlantas);
                tiposImpresoras.forEach((tipo, index) => {
                    data.push({
                        label: tipo,
                        data: labels.map(planta => datosPlantas[planta]?.[tipo] || 0),
                        backgroundColor: colores[index % colores.length]
                    });
                });
            } else {
                labels = [plantaSeleccionada];
                tiposImpresoras.forEach((tipo, index) => {
                    data.push({
                        label: tipo,
                        data: [datosPlantas[plantaSeleccionada]?.[tipo] || 0],
                        backgroundColor: colores[index % colores.length]
                    });
                });
            }

            return { labels, data };
        }

        var ctx = document.getElementById('graficoAsignaciones').getContext('2d');
        var datosIniciales = obtenerDatosPlanta("Todas");

        var grafico = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: datosIniciales.labels,
                datasets: datosIniciales.data
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { stacked: false },
                    y: { stacked: false, beginAtZero: true }
                },
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });

        document.getElementById('filtroPlanta').addEventListener('change', function() {
            let plantaSeleccionada = this.value;
            let nuevosDatos = obtenerDatosPlanta(plantaSeleccionada);
            grafico.data.labels = nuevosDatos.labels;
            grafico.data.datasets = nuevosDatos.data;
            grafico.update();
        });
    </script>

</body>
</html>
