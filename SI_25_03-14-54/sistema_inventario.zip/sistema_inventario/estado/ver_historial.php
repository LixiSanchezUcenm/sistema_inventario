<?php
include '../conexion.php'; // Conexión a la base de datos

// menu header
include '../includes/header.php';

// Verificar que el ID esté presente en la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Error: ID de impresora no especificado.');
}

$id_impresora = $_GET['id'];

// Obtener el serial de la impresora antes de buscar en historial_estados
$query_serial = "SELECT serial FROM impresoras WHERE id = ?";
$stmt_serial = $conn->prepare($query_serial);
$stmt_serial->bind_param("i", $id_impresora);
$stmt_serial->execute();
$result_serial = $stmt_serial->get_result();
$impresora = $result_serial->fetch_assoc();

if (!$impresora) {
    die("Error: Impresora no encontrada en la base de datos.");
}

$serial = $impresora['serial']; // Ahora tenemos el serial correcto

// Consulta para obtener el historial de cambios
$query_historial = "SELECT nuevo_estado, comentario, usuario, fecha FROM historial_estados WHERE serial = ? ORDER BY fecha DESC";
$stmt_historial = $conn->prepare($query_historial);
$stmt_historial->bind_param("s", $serial);
$stmt_historial->execute();
$resultado = $stmt_historial->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de Estados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	
	
		 <!-- Menu header -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
	
</head>
<body >
	
	<!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>
	
	<div class="container mt-4">
        <h2>Historial de Estados de la Impresora</h2>
		
		        <a href="listar_impresoras.php" class="btn btn-secondary">Volver</a>
		
        <table class="table table-bordered">
			
			
            <thead class="table-dark">
                <tr>
                    <th>Estado</th>
                    <th>Comentario</th>
                    <th>Usuario</th>
                    <th>Fecha de Cambio</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($resultado->num_rows > 0): ?>
                    <?php while ($fila = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><span class="badge bg-<?php echo getColorEstado($fila['nuevo_estado']); ?>"><?php echo ucfirst($fila['nuevo_estado']); ?></span></td>
                            <td><?php echo htmlspecialchars($fila['comentario']); ?></td>
                            <td><?php echo htmlspecialchars($fila['usuario']); ?></td>
                            <td><?php echo htmlspecialchars($fila['fecha']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">No hay historial de cambios para esta impresora.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>
	
	  
</body>
</html>

<?php
// Función para definir los colores según el estado
function getColorEstado($estado) {
    switch ($estado) {
        case 'buena': return 'success';
        case 'mantenimiento': return 'warning';
        case 'robada': return 'danger';
        case 'obsoleta': return 'secondary';
        default: return 'dark';
    }
}


?>
