<?php
include '../conexion.php';

// Obtener empresas para el selector
$empresas = mysqli_query($conn, "SELECT * FROM Empresas");

// Agregar planta
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar_planta'])) {
    $nombre = $_POST['nombre'];
    $id_empresa = $_POST['id_empresa'];
    $sql = "INSERT INTO plantas (nombre, id_empresa) VALUES ('$nombre', $id_empresa)";
    mysqli_query($conn, $sql);
}

// Eliminar planta
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM plantas WHERE id = $id";
    mysqli_query($conn, $sql);
	    header('Location: menu.php');

}




// Obtener plantas con su empresa
$plantas = mysqli_query($conn, "SELECT plantas.id, plantas.nombre, Empresas.nombre AS empresa FROM plantas INNER JOIN Empresas ON plantas.id_empresa = Empresas.id");
?>

<div class="container">
    <h3>plantas</h3>
    <form method="POST" class="mb-3">
        <div class="input-group">
            <input type="text" name="nombre" class="form-control" placeholder="Nombre de la planta" required>
            <select name="id_empresa" class="form-select" required>
                <option value="" disabled selected>Seleccionar Empresa</option>
                <?php while ($empresa = mysqli_fetch_assoc($empresas)) : ?>
                    <option value="<?= $empresa['id'] ?>"><?= $empresa['nombre'] ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="agregar_planta" class="btn btn-success">Agregar</button>
        </div>
    </form>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Empresa</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($planta = mysqli_fetch_assoc($plantas)) : ?>
                <tr>
                    <td><?= $planta['id'] ?></td>
                    <td><?= $planta['nombre'] ?></td>
                    <td><?= $planta['empresa'] ?></td>
                    <td>
<a href="plantas.php?eliminar=<?= $planta['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar planta?')">Eliminar</a>
						
						
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>


