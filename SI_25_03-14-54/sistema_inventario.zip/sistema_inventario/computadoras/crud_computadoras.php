<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}


$query = "SELECT Computadoras.*, 
                 Marcas_computadoras.nombre AS marca, 
                 Tipos_Computadoras.tipo AS tipo, 
                 Estados.nombre AS estado_nombre, 
                 COALESCE(Plantas.nombre, 'Almacén IT') AS ubicacion,
                 Computadoras.anio  -- Se agregó el campo anio
          FROM Computadoras 
          JOIN Marcas_computadoras ON Computadoras.id_marca = Marcas_computadoras.id
          JOIN Tipos_Computadoras ON Computadoras.id_tipo = Tipos_Computadoras.id
          JOIN Estados ON Computadoras.estado_actual = Estados.id
          LEFT JOIN Plantas ON Computadoras.ubicacion = Plantas.id";

// Ejecutar la consulta y verificar errores
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Error en la consulta: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Computadoras</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">Gestión de Computadoras</h2>
        
        <!-- Mostrar cantidad de registros obtenidos -->
        <?php 
        $num_rows = mysqli_num_rows($result);
        echo "<p class='text-center'>Registros encontrados: <strong>$num_rows</strong></p>"; 
        ?>

        <!-- Input de búsqueda -->
        <input type="text" id="buscador" class="form-control mb-3" placeholder="Buscar en cualquier campo...">

        <a href="agregar_computadoras.php" class="btn btn-success mb-3">Agregar Computadora</a>
	
		<a href="../garantias/listar_gt_computadora.php" class="btn btn-success mb-3">Listado Garantias</a>


        <table class="table table-bordered" id="tablaComputadoras">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Serial</th>
                    <th>Modelo</th>
                    <th>Marca</th>
                    <th>Tipo</th>
                    <th>RAM</th>
                    <th>Disco</th>
                    <th>Procesador</th>
                    <th>Sistema Operativo</th>
                    <th>Año</th> <!-- Nueva columna Año -->
                    <th>Estado</th>
                    <th>Ubicación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { 
                    // Verificar si la computadora está asignada (asignada == 1)
                    $ubicacion = isset($row['asignada']) && $row['asignada'] == 1 ? htmlspecialchars($row['ubicacion']) : "Almacén IT";
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['serial']); ?></td>
                        <td><?php echo htmlspecialchars($row['modelo']); ?></td>
                        <td><?php echo htmlspecialchars($row['marca']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><?php echo htmlspecialchars($row['ram']); ?></td>
                        <td><?php echo htmlspecialchars($row['disco']); ?></td>
                        <td><?php echo htmlspecialchars($row['procesador']); ?></td>
                        <td><?php echo htmlspecialchars($row['sistema_operativo']); ?></td>
                        <td><?php echo htmlspecialchars($row['anio']); ?></td> <!-- Mostrar el año -->
                        <td><?php echo htmlspecialchars($row['estado_nombre']); ?></td>
                        <td><?php echo $ubicacion; ?></td>
                        
<td>
    <div class="d-flex gap-2">
        <a href="editar_computadora.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
        <a href="eliminar_computadoras.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta computadora?');">Eliminar</a>
        <a href="../garantias/garantia_computadora.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Garantía</a>
    </div>
</td>

							
                        
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        document.getElementById("buscador").addEventListener("keyup", function() {
            let filtro = this.value.toLowerCase();
            let filas = document.querySelectorAll("#tablaComputadoras tbody tr");

            filas.forEach(function(fila) {
                let textoFila = fila.textContent.toLowerCase();
                fila.style.display = textoFila.includes(filtro) ? "" : "none";
            });
        });
    </script>

</body>
</html>
