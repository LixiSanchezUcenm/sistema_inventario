<?php
include '../conexion.php';

// menu header
include '../includes/header.php';

// Obtener el ID de la computadora a editar
if (!isset($_GET['id'])) {
    echo "ID de computadora no proporcionado.";
    exit;
}
$id = $_GET['id'];

// Obtener datos de la computadora
$query = "SELECT * FROM Computadoras WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$computadora = $result->fetch_assoc();

if (!$computadora) {
    echo "Computadora no encontrada.";
    exit;
}

// Obtener marcas y tipos de computadoras para los select
$marcas = $conn->query("SELECT * FROM marcas_computadoras");
$tipos = $conn->query("SELECT * FROM tipos_computadoras");

// Procesar formulario de actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial = $_POST['serial'];
    $modelo = $_POST['modelo'];
    $id_marca = $_POST['id_marca'];
    $id_tipo = $_POST['id_tipo'];
    $ram = $_POST['ram'];
    $disco = $_POST['disco'];
    $procesador = $_POST['procesador'];
    $sistema_operativo = $_POST['sistema_operativo'];
    $anio = $_POST['anio'];

    $updateQuery = "UPDATE Computadoras SET serial=?, modelo=?, id_marca=?, id_tipo=?, ram=?, disco=?, procesador=?, sistema_operativo=?, anio=? WHERE id=?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssiiisssii", $serial, $modelo, $id_marca, $id_tipo, $ram, $disco, $procesador, $sistema_operativo, $anio, $id);

    if ($stmt->execute()) {
        header("Location: crud_computadoras.php?mensaje=Computadora actualizada correctamente");
        exit;
    } else {
        echo "Error al actualizar la computadora.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Computadora</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
    </header>
    
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="text-center text-primary">Editar Computadora</h3>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Serial</label>
                    <input type="text" name="serial" class="form-control" value="<?php echo $computadora['serial']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Modelo</label>
                    <input type="text" name="modelo" class="form-control" value="<?php echo $computadora['modelo']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Marca</label>
                    <select name="id_marca" class="form-select" required>
                        <?php while ($marca = $marcas->fetch_assoc()) { ?>
                            <option value="<?php echo $marca['id']; ?>" <?php echo ($marca['id'] == $computadora['id_marca']) ? 'selected' : ''; ?>>
                                <?php echo $marca['nombre']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tipo</label>
                    <select name="id_tipo" class="form-select" required>
                        <?php while ($tipo = $tipos->fetch_assoc()) { ?>
                            <option value="<?php echo $tipo['id']; ?>" <?php echo ($tipo['id'] == $computadora['id_tipo']) ? 'selected' : ''; ?>>
                                <?php echo $tipo['tipo']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">RAM</label>
                    <input type="text" name="ram" class="form-control" value="<?php echo $computadora['ram']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Disco</label>
                    <input type="text" name="disco" class="form-control" value="<?php echo $computadora['disco']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Procesador</label>
                    <input type="text" name="procesador" class="form-control" value="<?php echo $computadora['procesador']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Sistema Operativo</label>
                    <input type="text" name="sistema_operativo" class="form-control" value="<?php echo $computadora['sistema_operativo']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Año</label>
                    <input type="number" name="anio" class="form-control" min="2000" max="2099" value="<?php echo $computadora['anio']; ?>" required>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success">Actualizar</button>
                    <a href="crud_computadoras.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
