<?php
include '../conexion.php';

// menú header
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Agregar computadora
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial = $_POST['serial'];
    $modelo = $_POST['modelo'];
    $id_marca = $_POST['id_marca'];
    $id_tipo = $_POST['id_tipo'];
    $disco = $_POST['disco'];
    $ram = $_POST['ram'];
    $procesador = $_POST['procesador'];
    $sistema_operativo = $_POST['sistema_operativo'];
    $anio = $_POST['anio']; 

    // Ubicación y estado inicial
    $ubicacion = 'Almacén IT';
    $estado = 'Buena';

    // Verificar si el serial ya existe
    $check_serial = "SELECT COUNT(*) as total FROM computadoras WHERE serial = '$serial'";
    $result = mysqli_query($conn, $check_serial);
    $row = mysqli_fetch_assoc($result);

    if ($row['total'] > 0) {
        echo "<script>alert('Error: Ya existe una computadora con este número de serial.'); window.location.href='crud_computadoras.php';</script>";
    } else {
        // Insertar datos en la base de datos si el serial no existe
        $insert = "INSERT INTO computadoras (serial, modelo, id_marca, id_tipo, disco, ram, procesador, sistema_operativo, estado_actual, ubicacion, anio) 
                   VALUES ('$serial', '$modelo', '$id_marca', '$id_tipo', '$disco', '$ram', '$procesador', '$sistema_operativo', 1, '$ubicacion', '$anio')";

        if (mysqli_query($conn, $insert)) {
            echo "<script>alert('Computadora agregada exitosamente'); window.location.href='crud_computadoras.php';</script>";
        } else {
            echo "<script>alert('Error al agregar computadora');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Computadora</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Agregar Computadora</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Serial</label>
                <input type="text" name="serial" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Modelo</label>
                <input type="text" name="modelo" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Marca</label>
                <select name="id_marca" class="form-control" required>
                    <?php
                    $marcas = mysqli_query($conn, "SELECT * FROM marcas_computadoras");
                    while ($marca = mysqli_fetch_assoc($marcas)) {
                        echo "<option value='{$marca['id']}'>{$marca['nombre']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Tipo</label>
                <select name="id_tipo" class="form-control" required>
                    <?php
                    $tipos = mysqli_query($conn, "SELECT * FROM tipos_computadoras");
                    while ($tipo = mysqli_fetch_assoc($tipos)) {
                        echo "<option value='{$tipo['id']}'>{$tipo['tipo']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Disco</label>
                <input type="text" name="disco" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">RAM</label>
                <input type="text" name="ram" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Procesador</label>
                <input type="text" name="procesador" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Sistema Operativo</label>
                <input type="text" name="sistema_operativo" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Año</label>
                <input type="number" name="anio" class="form-control" min="2000" max="2099" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a href="crud_computadoras.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
