<?php
include '../conexion.php';
include '../includes/header.php'; // Asegúrate de que header.php no tiene errores
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Ubicaciones</title>

    <!-- Bootstrap CSS (solo una vez) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="../styles.css">
</head>
<body>


        
    <!-- Menú de navegación -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-4">
        <!-- Pestañas -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="tipos-tab" data-bs-toggle="tab" data-bs-target="#tipos" type="button" role="tab">Tipos</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="marcas-tab" data-bs-toggle="tab" data-bs-target="#marcas" type="button" role="tab">Marcas</button>
            </li>
        </ul>
        
        <div class="tab-content mt-3" id="myTabContent">
            <div class="tab-pane fade show active" id="tipos" role="tabpanel">
                <?php include 'tipos.php'; ?>
            </div>
            <div class="tab-pane fade" id="marcas" role="tabpanel">
                <?php include 'marcas.php'; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (solo una vez y cargado al final) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Debug: Verifica si Bootstrap está cargado correctamente -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            if (typeof bootstrap === "undefined") {
                console.error("Bootstrap JS no se está cargando correctamente.");
            } else {
                console.log("Bootstrap cargado correctamente.");
            }
        });
    </script>
</body>
</html>
