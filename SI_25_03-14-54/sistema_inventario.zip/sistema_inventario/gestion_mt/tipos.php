<?php
include '../conexion.php'; // Conexión a la base de datos



// Insertar un nuevo tipo de impresora
if (isset($_POST['agregar_tipo'])) {
    $nombre_tipo = $_POST['nombre_tipo'];
    $query = "INSERT INTO tipos_impresoras (tipo) VALUES ('$nombre_tipo')";
    mysqli_query($conn, $query);
    header('Location: menu.php');
}

// Eliminar un tipo de impresora
if (isset($_GET['eliminar_tipo'])) {
    $id = $_GET['eliminar_tipo'];
    $query = "DELETE FROM tipos_impresoras WHERE id = $id";
    mysqli_query($conn, $query);
    header('Location: menu.php');
}
?>

<div class="container mt-4">
    <h2>Gestión de Marcas y Tipos de Impresoras</h2>
    <div class="row">
       
        <div class="col-md-6">
            <h4>Agregar Tipo de Impresora</h4>
            <form method="POST">
                <input type="text" name="nombre_tipo" class="form-control mb-2" placeholder="Tipo de impresora" required>
                <button type="submit" name="agregar_tipo" class="btn btn-primary">Agregar</button>
            </form>
        </div>
    </div>
    
    <div class="row mt-4">
        
        
        <div class="col-md-6">
            <h4>Lista de Tipos de Impresoras</h4>
            <table class="table table-bordered">
                <thead><tr><th>ID</th><th>Tipo</th><th>Acción</th></tr></thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM Tipos_Impresoras");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['tipo']}</td>
                            <td><a href='menu.php?eliminar_tipo={$row['id']}' class='btn btn-danger btn-sm'>Eliminar</a></td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



