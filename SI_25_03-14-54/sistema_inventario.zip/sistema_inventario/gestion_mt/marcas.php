<?php
include '../conexion.php'; // Conexión a la base de datos

// Evitar que se envíen encabezados antes de realizar redirecciones
ob_start(); // Comienza el almacenamiento en búfer de salida

// Insertar una nueva marca
if (isset($_POST['agregar_marca'])) {
    $nombre_marca = $_POST['nombre_marca'];
    $query = "INSERT INTO Marcas (nombre) VALUES ('$nombre_marca')";
    mysqli_query($conn, $query);
    // Recargar la página de marcas después de agregar
    echo "<script>window.location.href = 'menu.php';</script>";
    exit();
}

// Eliminar una marca
if (isset($_GET['eliminar_marca'])) {
    $id = $_GET['eliminar_marca'];
    $query = "DELETE FROM Marcas WHERE id = $id";
    mysqli_query($conn, $query);
    // Recargar la página de marcas después de eliminar
    echo "<script>window.location.href = 'menu.php';</script>";
    exit();
}

ob_end_flush(); // Termina el almacenamiento en búfer de salida
?>

<div class="container mt-4">
    <h2>Gestión de Marcas y Tipos de Impresoras</h2>
    <div class="row">
        <div class="col-md-6">
            <h4>Agregar Marca</h4>
            <form method="POST">
                <input type="text" name="nombre_marca" class="form-control mb-2" placeholder="Nombre de la marca" required>
                <button type="submit" name="agregar_marca" class="btn btn-primary">Agregar</button>
            </form>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <h4>Lista de Marcas</h4>
            <table class="table table-bordered">
                <thead><tr><th>ID</th><th>Nombre</th><th>Acción</th></tr></thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM Marcas");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['nombre']}</td>
                            <td><a href='marcas.php?eliminar_marca={$row['id']}' class='btn btn-danger btn-sm'>Eliminar</a></td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
