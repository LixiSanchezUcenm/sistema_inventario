<?php
include 'conexion.php';
include 'funciones.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    echo "<script>alert('Debes iniciar sesión primero'); window.location.href='login.php';</script>";
    exit();
}

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Si el usuario tiene rol "sin acceso", lo redirigimos al login con un mensaje
if ($rol == 'sin acceso') {
    echo "<script>alert('No tienes permiso para acceder al sistema.'); window.location.href='login.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Inventario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Bienvenido al Sistema de Inventario</h1> 
        <div class="user-info text-end">
            <h5><?= $usuario ?></h5>
            <p> <?= $rol ?></p>
        </div>
    </header>

    <!-- Menú de navegación horizontal con logo -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                <img src="logo.png" alt="Logo" class="logo me-2">
          
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
						
						
						
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Gestion de Impresoras</a>
         
						<ul class="dropdown-menu">
                     <li><a class="dropdown-item" href="asignaciones/asignar.php">Gestión de Asignaciones</a></li>
                   <li><a class="dropdown-item" href="asignaciones/historial_asignaciones.php">Historial de Asignaciones</a></li>
                      <li><a class="dropdown-item" href="estado/listar_impresoras.php">Estado Impresoras</a></li>
							
							<li class="nav-item">
                            <a href="admin/crud_impresoras.php" class="nav-link">Registro Impresoras</a>
                        </li>
							
							
                        </ul>
                    </li>
					


				
				 <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración Computadoras</a>
                           
					 <ul class="dropdown-menu">
			  <li><a class="dropdown-item" href="computadoras/crud_computadoras.php">Agregar Computadoras</a></li>
  <li><a class="dropdown-item" href="asignacion_com/asignar_computadora.php">asignar computadora Computadoras</a></li>
			<li><a class="dropdown-item" href="asignacion_com/listar_computadora.php">estado Computadoras</a></li>
			<li><a class="dropdown-item" href="asignacion_com/historial_asignaciones.php">historial</a></li>

                            </ul>
                        </li>
		
					
					
					
				 <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración Componentes</a>
                            
					 <ul class="dropdown-menu">
					 <li><a class="dropdown-item" href="componentes/crud_componentes.php">Agregar Componentes</a></li>
                      <li><a class="dropdown-item" href="asignacion_compo/asignacion_componentes.php">asignar componentes</a></li>
					<li><a class="dropdown-item" href="asignacion_compo/listar_componentes.php">estado componentes</a></li>
					<li><a class="dropdown-item" href="asignacion_compo/historial_asignaciones.php">historial</a></li>

                            </ul>
                        </li>
					
				
					
					          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Reportes</a>
                            
								  <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="reportes/listar_asignaciones.php">Computadora</a></li>
                                <li><a class="dropdown-item" href="reportes/asignacion_impresoras.php">Impresoras</a></li>		
                            </ul>		
                        </li>
					
				

                    <?php if ($rol == 'administrador') : ?>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="empresa/menu.php">Empresa</a></li>
                                <li><a class="dropdown-item" href="gestion_mt/menu.php">Impresoras</a></li>		
								   <li><a class="dropdown-item" href="gestion_com/menu.php">Computadoras y Componentes</a></li>		

								
								             <li><a class="dropdown-item" href="importacion/importar.php">Importaciones</a></li>		
								
                            </ul>		
                        </li>
					
					
                        <li class="nav-item">
                            <a href="usuarios/usuarios.php" class="nav-link">Gestión de Usuarios</a>
                        </li>
					
					
                    <?php endif; ?>

                    <li class="nav-item">
                        <a href="logout.php" class="nav-link text-danger">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="content">
        <!-- Contenido adicional aquí -->
    </div>

</body>
</html>
