<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serial = mysqli_real_escape_string($conn, trim($_POST['serial']));
    $modelo = mysqli_real_escape_string($conn, trim($_POST['modelo']));
    $id_marca = intval($_POST['id_marca']);
    $id_tipo = intval($_POST['id_tipo']);

    // Verificar que los valores no estén vacíos
    if (empty($serial) || empty($modelo) || empty($id_marca) || empty($id_tipo)) {
        echo "<script>alert('Todos los campos son obligatorios.');</script>";
    } else {
        // Verificar si el serial ya existe en la base de datos
        $check_serial = "SELECT COUNT(*) as total FROM componentes WHERE serial = '$serial'";
        $result_serial = mysqli_query($conn, $check_serial);
        $row_serial = mysqli_fetch_assoc($result_serial);

        if ($row_serial['total'] > 0) {
            echo "<script>alert('Error: El número de serie ya está registrado.');</script>";
        } else {
            // Verificar si la marca y el tipo existen
            $result_marca = mysqli_query($conn, "SELECT id FROM marcas_computadoras WHERE id = $id_marca");
            $result_tipo = mysqli_query($conn, "SELECT id FROM Tipos_componentes WHERE id = $id_tipo");

            if (mysqli_num_rows($result_marca) == 0 || mysqli_num_rows($result_tipo) == 0) {
                echo "<script>alert('Error: Marca o Tipo de componente no válidos.');</script>";
            } else {
                // Definir ubicación y estado inicial
                $ubicacion = 'Almacén IT';
                $estado_id = 1; // Se asume que el estado 'Buena' tiene ID 1
                $asignada = 0;

                // Insertar el componente en la base de datos
                $insert = "INSERT INTO componentes (serial, modelo, id_marca, id_tipo, ubicacion, estado_id, asignada) 
                           VALUES ('$serial', '$modelo', $id_marca, $id_tipo, '$ubicacion', $estado_id, $asignada)";

                if (mysqli_query($conn, $insert)) {
                    echo "<script>alert('Componente agregado exitosamente'); window.location.href='crud_componentes.php';</script>";
                } else {
                    echo "<script>alert('Error al agregar componente: " . mysqli_error($conn) . "');</script>";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Componente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1>
        <div class="user-info text-end"></div>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Agregar Componente</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Serial</label>
                <input type="text" name="serial" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Modelo</label>
                <input type="text" name="modelo" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Marca</label>
                <select name="id_marca" class="form-control" required>
                    <option value="">Seleccione una marca</option>
                    <?php
                    $marcas = mysqli_query($conn, "SELECT * FROM marcas_computadoras ORDER BY nombre DESC");
                    while ($marca = mysqli_fetch_assoc($marcas)) {
                        echo "<option value='{$marca['id']}'>{$marca['nombre']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Tipo</label>
                <select name="id_tipo" class="form-control" required>
                    <option value="">Seleccione un tipo</option>
                    <?php
                    $tipos = mysqli_query($conn, "SELECT * FROM Tipos_componentes");
                    while ($tipo = mysqli_fetch_assoc($tipos)) {
                        echo "<option value='{$tipo['id']}'>{$tipo['nombre']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a href="crud_componentes.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
