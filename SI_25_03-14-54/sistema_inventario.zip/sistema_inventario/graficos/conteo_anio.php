<?php
include '../conexion.php';

// Menu header
include '../includes/header.php';


// Obtener todas las plantas
$plantas_query = "SELECT id, nombre FROM plantas";
$plantas_resultado = mysqli_query($conn, $plantas_query);
$plantas = ['Almacén IT'];
$plantas_id = [];
while ($fila = mysqli_fetch_assoc($plantas_resultado)) {
    $plantas[] = $fila['nombre'];
    $plantas_id[$fila['id']] = $fila['nombre'];
}

// Obtener datos generales por año (sin filtro)
$sqlAnio = "SELECT anio, COUNT(*) AS cantidad FROM computadoras GROUP BY anio ORDER BY anio ASC";
$resultadoAnio = mysqli_query($conn, $sqlAnio);
$datosAnio = [];
while ($fila = mysqli_fetch_assoc($resultadoAnio)) {
    $datosAnio[$fila['anio']] = $fila['cantidad'];
}

// Obtener datos de computadoras por marca
$sqlMarca = "SELECT m.nombre AS marca, COUNT(*) AS cantidad
             FROM computadoras c
             JOIN marcas_computadoras m ON c.id_marca = m.id
             GROUP BY m.nombre
             ORDER BY cantidad DESC";
$resultadoMarca = mysqli_query($conn, $sqlMarca);
$datosMarca = [];
while ($fila = mysqli_fetch_assoc($resultadoMarca)) {
    $datosMarca[$fila['marca']] = $fila['cantidad'];
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario de Computadoras</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	 <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <link rel="stylesheet" href="../styles.css">
	
    <style>
        .chart-container { height: 250px; }
    </style>
</head>
<body>
 <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>
	
	    
    <div class="container mt-4">
        <div class="text-center my-3">
            <a href="conteo_estado.php" class="btn btn-primary">Estados</a>
            <a href="conteo_anio.php" class="btn btn-primary">Año y Marca</a>
            <a href="conteo_depto.php" class="btn btn-primary">Departamentos</a>
        </div>

		
		
<div class="container mt-4">
    <h2 class="text-center">📊 Inventario de Computadoras por Año</h2>

    <!-- Filtro de planta -->
    <div class="row mt-3">
        <div class="col-md-6">
            <label for="filtroPlanta" class="form-label">Selecciona una Planta:</label>
            <select id="filtroPlanta" class="form-select mb-2">
                <option value="Todas">Todas</option>
                <?php foreach ($plantas as $planta) { ?>
                    <option value="<?= $planta; ?>"><?= $planta; ?></option>
                <?php } ?>
            </select>
        </div>
    </div>

    <!-- Tabla y gráfico por Año -->
    <div class="row mt-3">
		

        <div class="col-md-6">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr><th>Año</th><th>Cantidad</th></tr>
                </thead>
                <tbody id="tablaAnio">
                    <?php foreach ($datosAnio as $anio => $cantidad) { ?>
                        <tr><td><?= $anio; ?></td><td><?= $cantidad; ?></td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 chart-container">
            <canvas id="graficoComputadoras"></canvas>
        </div>
    </div>

    <!-- Tabla y gráfico por Marca -->
    <div class="row mt-3">
				    <h2 class="text-center">📊 Inventario de Computadoras por Marcas</h2>

        <div class="col-md-6">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr><th>Marca</th><th>Cantidad</th></tr>
                </thead>
                <tbody id="tablaMarcas">
                    <?php foreach ($datosMarca as $marca => $cantidad) { ?>
                        <tr><td><?= $marca; ?></td><td><?= $cantidad; ?></td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6 chart-container">
            <canvas id="graficoMarcas"></canvas>
        </div>
    </div>
</div>

<script>
    // Gráfico de computadoras por año
    const datosAnio = <?= json_encode($datosAnio); ?>;
    let ctxAnio = document.getElementById('graficoComputadoras').getContext('2d');

    let chartAnio = new Chart(ctxAnio, {
        type: 'bar',
        data: {
            labels: Object.keys(datosAnio),
            datasets: [{
                label: 'Computadoras por Año',
                data: Object.values(datosAnio),
                backgroundColor: '#E75300'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true } }
        }
    });

    // Gráfico de computadoras por marca
    const datosMarca = <?= json_encode($datosMarca); ?>;
    let ctxMarca = document.getElementById('graficoMarcas').getContext('2d');

    let colores = [ '#E75300','#33FF57', '#3357FF', '#FF33A1', '#A133FF', '#33FFF5', '#FF5733', '#F5FF33', '#FF8C33', '#8C33FF', '#33FF8C'];

    let chartMarcas = new Chart(ctxMarca, {
        type: 'pie',
        data: {
            labels: Object.keys(datosMarca),
            datasets: [{
                data: Object.values(datosMarca),
                backgroundColor: colores.slice(0, Object.keys(datosMarca).length)
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });

    // Función para actualizar la tabla y el gráfico según la planta seleccionada
    $("#filtroPlanta").change(function () {
        let planta = this.value;
        $.ajax({
            url: 'actualizar_datos.php',
            type: 'POST',
            data: { planta: planta },
            success: function (response) {
                let data = JSON.parse(response);
                $("#tablaAnio").html(data.htmlTabla);
                actualizarGraficoAnio(data.labels, data.values);
            }
        });
    });

    function actualizarGraficoAnio(labels, values) {
        chartAnio.data.labels = labels;
        chartAnio.data.datasets[0].data = values;
        chartAnio.update();
    }
</script>

</body>
</html>
