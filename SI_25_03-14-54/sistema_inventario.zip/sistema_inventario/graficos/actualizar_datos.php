<?php
include '../conexion.php';

$planta = $_POST['planta'];
$datosAnio = [];
$htmlTabla = '';

if ($planta === "Todas") {
    // Filtrar todas las computadoras agrupadas por año
    $sql = "SELECT c.anio, COUNT(*) AS cantidad
            FROM computadoras c
            GROUP BY c.anio
            ORDER BY c.anio ASC";
} elseif ($planta === "Almacén IT") {
    // Filtrar solo computadoras NO asignadas (Almacén IT)
    $sql = "SELECT c.anio, COUNT(*) AS cantidad
            FROM computadoras c
            LEFT JOIN asignaciones_computadora a ON c.id = a.id_computadora AND a.activo = 1
            WHERE a.id_computadora IS NULL
            GROUP BY c.anio
            ORDER BY c.anio ASC";
} else {
    // Filtrar por una planta específica
    $sql = "SELECT c.anio, COUNT(*) AS cantidad
            FROM computadoras c
            INNER JOIN asignaciones_computadora a ON c.id = a.id_computadora AND a.activo = 1
            INNER JOIN plantas p ON a.planta = p.id
            WHERE p.nombre = '$planta'
            GROUP BY c.anio
            ORDER BY c.anio ASC";
}

$resultado = mysqli_query($conn, $sql);

while ($fila = mysqli_fetch_assoc($resultado)) {
    $datosAnio[$fila['anio']] = $fila['cantidad'];
    $htmlTabla .= "<tr><td>{$fila['anio']}</td><td>{$fila['cantidad']}</td></tr>";
}

mysqli_close($conn);

echo json_encode([
    'labels' => array_keys($datosAnio),
    'values' => array_values($datosAnio),
    'htmlTabla' => $htmlTabla
]);
?>
