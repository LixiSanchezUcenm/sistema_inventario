<?php
// Conexión a la base de datos
include '../conexion.php';

// Menu header
include '../includes/header.php';

// 1. Obtener datos de asignaciones por planta y departamento
$sqlPlantaDep = "SELECT 
                    p.nombre AS planta_nombre,
                    d.nombre AS departamento_nombre,
                    COUNT(ac.id) AS total_computadoras
                FROM asignaciones_computadora ac
                JOIN computadoras c ON ac.id_computadora = c.id
                JOIN usuarios u ON ac.id_usuario = u.usuario
                LEFT JOIN departamentos d ON u.departamento_id = d.id
                LEFT JOIN plantas p ON ac.planta = p.id
                WHERE ac.activo = 1
                GROUP BY p.nombre, d.nombre
                ORDER BY p.nombre, d.nombre";

$resultPlantaDep = $conn->query($sqlPlantaDep);

// Estructurar los datos
$dataPlantas = [];
$departamentos = [];

while ($row = $resultPlantaDep->fetch_assoc()) {
    $planta = $row['planta_nombre'];
    $departamento = $row['departamento_nombre'];
    
    if (!isset($dataPlantas[$planta])) {
        $dataPlantas[$planta] = [];
    }
    $dataPlantas[$planta][$departamento] = $row['total_computadoras'];

    if (!in_array($departamento, $departamentos)) {
        $departamentos[] = $departamento;
    }
}

// Datos globales (sumatoria de todas las plantas)
$globalData = [];
foreach ($dataPlantas as $planta => $departamentosData) {
    foreach ($departamentosData as $dep => $cantidad) {
        $globalData[$dep] = (isset($globalData[$dep]) ? $globalData[$dep] : 0) + $cantidad;
    }
}

// 2. Obtener datos de computadoras asignadas por departamento
$sqlDep = "SELECT 
                d.nombre AS departamento_nombre,
                COUNT(ac.id) AS total_computadoras
            FROM asignaciones_computadora ac
            JOIN computadoras c ON ac.id_computadora = c.id
            JOIN usuarios u ON ac.id_usuario = u.usuario
            LEFT JOIN departamentos d ON u.departamento_id = d.id
            WHERE ac.activo = 1
            GROUP BY d.nombre
            ORDER BY d.nombre";

$resultDep = $conn->query($sqlDep);

// Estructurar los datos
$dataDepartamentos = [];
$totalGeneral = 0;

while ($row = $resultDep->fetch_assoc()) {
    $dataDepartamentos[$row['departamento_nombre']] = $row['total_computadoras'];
    $totalGeneral += $row['total_computadoras'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Computadoras</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <link rel="stylesheet" href="../styles.css">
    
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        select, input { margin: 10px; padding: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: black; color: white; } /* Encabezados en negro */
        .chart-container {
            width: 600px; /* Aumenta el tamaño del gráfico */
            height: 400px;
            margin: 20px auto; /* Centra el gráfico */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        canvas {
            width: 100% !important;
            height: 100% !important;
        }
        h2 { margin-top: 30px; } /* Mayor separación en el título */
    </style>
</head>
<body>
    
    <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="text-center my-3">
            <a href="conteo_estado.php" class="btn btn-primary">Estados</a>
            <a href="conteo_anio.php" class="btn btn-primary">Año y Marca</a>
            <a href="conteo_depto.php" class="btn btn-primary">Departamentos</a>
        </div>

        <h2>📊 Computadoras Asignadas por Departamento</h2>

        <table>
            <thead>
                <tr>
                    <th>Departamento</th>
                    <?php foreach ($dataDepartamentos as $dep => $cantidad): ?>
                        <th><?php echo $dep; ?></th>
                    <?php endforeach; ?>
                    <th>Total General</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Cantidad</strong></td>
                    <?php foreach ($dataDepartamentos as $cantidad): ?>
                        <td><?php echo $cantidad; ?></td>
                    <?php endforeach; ?>
                    <td class="total-row"><strong><?php echo $totalGeneral; ?></strong></td>
                </tr>
            </tbody>
        </table>

        <h2>Reporte de Computadoras por Planta y Departamento</h2>

        <label for="filtroPlanta">Selecciona una Planta:</label>
        <select id="filtroPlanta">
            <option value="todas">Todas</option>
            <?php foreach (array_keys($dataPlantas) as $planta): ?>
                <option value="<?php echo $planta; ?>"><?php echo $planta; ?></option>
            <?php endforeach; ?>
        </select>

        <table id="tablaPlantas">
            <thead>
                <tr>
                    <th>Planta</th>
                    <?php foreach ($departamentos as $dep): ?>
                        <th><?php echo $dep; ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dataPlantas as $planta => $departamentosData): ?>
                    <tr data-planta="<?php echo $planta; ?>">
                        <td><?php echo $planta; ?></td>
                        <?php foreach ($departamentos as $dep): ?>
                            <td><?php echo isset($departamentosData[$dep]) ? $departamentosData[$dep] : 0; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="chart-container">
            <canvas id="grafico"></canvas>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var rawData = <?php echo json_encode($dataPlantas); ?>;
            var globalData = <?php echo json_encode($globalData); ?>;
            
            var ctx = document.getElementById('grafico').getContext('2d');
            var grafico = new Chart(ctx, {
                type: 'bar',
                data: { labels: [], datasets: [{ label: 'Computadoras', data: [], backgroundColor: '#E75300', borderColor: '#E75300', borderWidth: 1 }] },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } } }
            });

            function actualizarGrafico(planta) {
                var labels = [], values = [];

                if (planta === "todas") {
                    Object.keys(globalData).forEach(dep => { labels.push(dep); values.push(globalData[dep]); });
                } else if (planta && rawData[planta]) {
                    Object.keys(rawData[planta]).forEach(dep => { labels.push(dep); values.push(rawData[planta][dep]); });
                }

                grafico.data.labels = labels;
                grafico.data.datasets[0].data = values;
                grafico.update();
            }

            $("#filtroPlanta").on("change", function() { actualizarGrafico($(this).val()); });

            actualizarGrafico("todas");
        });
    </script>

</body>
</html>
