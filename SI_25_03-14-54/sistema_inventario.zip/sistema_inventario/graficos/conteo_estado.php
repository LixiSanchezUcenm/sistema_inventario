<?php
include '../conexion.php';

// menu header
include '../includes/header.php';

// Obtener los estados
$estados_query = "SELECT id, nombre FROM estados";
$estados_resultado = mysqli_query($conn, $estados_query);
$estados = [];
$estados_nombres = [];
while ($fila = mysqli_fetch_assoc($estados_resultado)) {
    $estados[$fila['id']] = $fila['nombre'];
    $estados_nombres[] = $fila['nombre'];
}

// Obtener las plantas
$plantas_query = "SELECT id, nombre FROM plantas";
$plantas_resultado = mysqli_query($conn, $plantas_query);
$plantas = ['Almacén IT'];
$plantas_id = [];
while ($fila = mysqli_fetch_assoc($plantas_resultado)) {
    $plantas[] = $fila['nombre'];
    $plantas_id[$fila['id']] = $fila['nombre'];
}

// Obtener el conteo de computadoras por estado y planta
$conteo = [];
$sql = "SELECT IFNULL(p.nombre, 'Almacén IT') AS planta, e.nombre AS estado, COUNT(*) AS cantidad
        FROM computadoras c
        LEFT JOIN estados e ON c.estado_actual = e.id
        LEFT JOIN asignaciones_computadora a ON c.id = a.id_computadora AND a.activo = 1
        LEFT JOIN plantas p ON a.planta = p.id
        GROUP BY planta, e.nombre";

$resultado = mysqli_query($conn, $sql);
while ($fila = mysqli_fetch_assoc($resultado)) {
    $planta = $fila['planta'];
    $estado = $fila['estado'];
    $conteo[$planta][$estado] = $fila['cantidad'];
}

// Obtener el total por estado
$sql_estados = "SELECT e.nombre AS estado, COUNT(*) AS total 
                FROM computadoras c 
                LEFT JOIN estados e ON c.estado_actual = e.id 
                GROUP BY e.nombre";
$result_estados = mysqli_query($conn, $sql_estados);
$conteo_estados = [];
while ($row = mysqli_fetch_assoc($result_estados)) {
    $conteo_estados[$row['estado']] = $row['total'];
}

// Obtener el total general
$sql_total = "SELECT COUNT(*) AS total_general FROM computadoras";
$result_total = mysqli_query($conn, $sql_total);
$total_general = mysqli_fetch_assoc($result_total)['total_general'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Conteo de Computadoras</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	
		 <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
    <link rel="stylesheet" href="../styles.css">
	
	
</head>
<body>

<?php include '../includes/navbar.php'; ?>

<div class="container mt-4">
	
	  <div class="text-center my-3">
            <a href="conteo_estado.php" class="btn btn-primary">Estados</a>
            <a href="conteo_anio.php" class="btn btn-primary">Año y Marca</a>
            <a href="conteo_depto.php" class="btn btn-primary">Departamentos</a>
        </div>
	
	
    <h2 class="text-center mb-4">📊 Conteo de Computadoras</h2>

    <table class="table table-bordered text-center">
        <thead>
            <tr>
                <th>Estado</th>
                <?php foreach ($conteo_estados as $estado => $cantidad) { ?>
                    <th><?php echo ucfirst($estado); ?></th>
                <?php } ?>
                <th>Total General</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Cantidad</td>
                <?php foreach ($conteo_estados as $cantidad) { ?>
                    <td><?php echo $cantidad; ?></td>
                <?php } ?>
                <td><?php echo $total_general; ?></td>
            </tr>
        </tbody>
    </table>
</div>

<div class="container mt-4">
    <h2 class="text-center">📊 Conteo de Computadoras por Planta</h2>
    <div class="mb-3">
        <label for="filtroPlanta" class="form-label">Selecciona una Planta:</label>
        <select id="filtroPlanta" class="form-select">
            <option value="Todas">Todas</option>
            <?php foreach ($plantas as $planta) { ?>
                <option value="<?php echo $planta; ?>"><?php echo $planta; ?></option>
            <?php } ?>
        </select>
    </div>

    <table class="table table-bordered text-center">
        <thead class="table-dark">
            <tr>
                <th>Planta</th>
                <?php foreach ($estados as $estado) { ?>
                    <th><?php echo ucfirst($estado); ?></th>
                <?php } ?>
            </tr>
        </thead>
        <tbody id="tablaConteo">
            <?php foreach ($conteo as $planta => $datos) { ?>
                <tr>
                    <td><strong><?php echo $planta; ?></strong></td>
                    <?php foreach ($estados as $estado) { ?>
                        <td><?php echo isset($datos[$estado]) ? $datos[$estado] : 0; ?></td>
                    <?php } ?>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <canvas id="graficoComputadoras" style="max-width: 400px; height: 300px;"></canvas>
    </div>
</div>

<script>
    const conteo = <?php echo json_encode($conteo); ?>;
    let ctx = document.getElementById('graficoComputadoras').getContext('2d');

    function getDataForChart(planta) {
        let estados = <?php echo json_encode(array_values($estados)); ?>;
        let data = estados.map(estado => planta === "Todas" ? 
            Object.values(conteo).reduce((sum, p) => sum + (p[estado] || 0), 0) :
            (conteo[planta]?.[estado] || 0)
        );
        return { estados, data };
    }

    function updateTable(planta) {
        let tablaConteo = document.getElementById("tablaConteo");
        tablaConteo.innerHTML = "";
        if (planta === "Todas") {
            for (const [planta, datos] of Object.entries(conteo)) {
                let row = `<tr><td><strong>${planta}</strong></td>`;
                <?php foreach ($estados as $estado) { ?>
                    row += `<td>${datos["<?php echo $estado; ?>"] || 0}</td>`;
                <?php } ?>
                row += `</tr>`;
                tablaConteo.innerHTML += row;
            }
        } else {
            let row = `<tr><td><strong>${planta}</strong></td>`;
            <?php foreach ($estados as $estado) { ?>
                row += `<td>${conteo[planta]?.["<?php echo $estado; ?>"] || 0}</td>`;
            <?php } ?>
            row += `</tr>`;
            tablaConteo.innerHTML += row;
        }
    }

    let { estados, data } = getDataForChart("Todas");
    let chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: estados,
            datasets: [{
                data: data,
                backgroundColor: ['#FF5733','#C3911a ', '#33FF57', '#3357FF', '#FF33A8', ' #E9511E ','#FFA733']

			
			 }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top' },
                title: { display: true, text: 'Distribución de Computadoras' }
            }
        }
    });

    document.getElementById("filtroPlanta").addEventListener("change", function () {
        let plantaSeleccionada = this.value;
        let { estados, data } = getDataForChart(plantaSeleccionada);
        chart.data.datasets[0].data = data;
        chart.update();
        updateTable(plantaSeleccionada);
    });
</script>

</body>
</html>
