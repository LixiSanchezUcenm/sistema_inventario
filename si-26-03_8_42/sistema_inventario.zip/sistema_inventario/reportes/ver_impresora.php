<?php
include '../conexion.php';

if (!isset($_GET['id'])) {
    die("Error: No se ha proporcionado un ID válido.");
}

$id_asignacion = $_GET['id'];

$sql = "SELECT 
            a.id AS id_asignacion,
            u.nombre AS nombre_usuario, 
            u.puesto AS puesto_usuario, 
            d.nombre AS nombre_departamento, 
            i.serial AS serie_impresora, 
            i.modelo AS modelo_impresora, 
            m.nombre AS marca_impresora, 
            p.PDV, 
            t.tipo AS tipo_impresora, 
            p.descripcion AS nombre_pdv, 
            pl.nombre AS nombre_planta, 
            e.nombre AS nombre_empresa, 
            a.fecha_asignacion, 
            a.asignado_por,
            ua.nombre AS nombre_asignador
        FROM Asignaciones a
        JOIN Usuarios u ON a.usuario = u.usuario
        LEFT JOIN Departamentos d ON u.departamento_id = d.id
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Marcas m ON i.id_marca = m.id
        JOIN Tipos_Impresoras t ON i.id_tipo = t.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        JOIN Plantas pl ON p.id_planta = pl.id
        JOIN Empresas e ON pl.id_empresa = e.id
        JOIN Usuarios ua ON a.asignado_por = ua.usuario
        WHERE a.id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

$stmt->bind_param("i", $id_asignacion);
$stmt->execute();
$result = $stmt->get_result();
$asignacion = $result->fetch_assoc();

if (!$asignacion) {
    die("Error: No se encontró la asignación en la base de datos.");
}

$nombre_departamento = !empty($asignacion['nombre_departamento']) ? strtoupper($asignacion['nombre_departamento']) : "NO ESPECIFICADO";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoja de Asignación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        @page {
            size: letter; /* Tamaño carta */
            margin: 20mm;
        }
        
        body {
            font-family: Arial, sans-serif;
            max-width: 800px; /* Ajusta a tamaño carta */
            margin: auto;
            background-color: #f8f9fa;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .encabezado {
	 margin-bottom: 20px; /* Espacio extra debajo del encabezado */

            border-top: 3px solid orange;
            border-bottom: 3px solid blue;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        @media print {
            body {
                background: none;
            }
            .container {
                box-shadow: none;
                width: 100%;
                max-width: none;
                padding: 0;
            }
            .no-print {
                display: none !important;
            }
        }
    </style>

    <script>
        function imprimirHoja() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="container mt-4">
        <div class="encabezado">
            <div style="width: 20%;">
                <img src="../logo.png" alt="Logo" style="height: 60px;">
            </div>
            <div style="flex: 1; text-align: center; font-size: 14px; font-weight: bold;">
				
                <?= strtoupper($asignacion['nombre_empresa']) ?><br>
                ASIGNACIÓN DE EQUIPO INFORMÁTICO
            </div>
            <div style="width: 20%; text-align: right; font-size: 10px;">
				
				<div><strong>Código:</strong> IT-<?= $asignacion['id_asignacion'] ?></div>

				
                <div><strong>Revisión:</strong> 1.2</div>
                <div><strong>Fecha:</strong> <?= date("d/m/Y", strtotime($asignacion['fecha_asignacion'])) ?></div>
            </div>
        </div>

        <p >Yo <strong><?= strtoupper($asignacion['nombre_usuario']) ?></strong>, encargado de la tienda <strong><?= strtoupper($asignacion['nombre_pdv']) ?></strong>, con el PDV <strong><?= $asignacion['PDV'] ?></strong> de la planta <strong><?= strtoupper($asignacion['nombre_planta']) ?></strong>, HAGO CONSTAR que estoy recibiendo de la empresa <strong><?= strtoupper($asignacion['nombre_empresa']) ?></strong> el siguiente equipo para el área de <strong><?= $nombre_departamento ?></strong>, mismo que se entrega como herramienta de trabajo con las siguientes descripciones:</p>

        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>DESCRIPCIÓN</th>
                    <th>MARCA</th>
                    <th>MODELO</th>
                    <th>SERIE</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><?= strtoupper($asignacion['tipo_impresora']) ?></td>
                    <td><?= $asignacion['marca_impresora'] ?></td>
                    <td><?= $asignacion['modelo_impresora'] ?></td>
                    <td><?= $asignacion['serie_impresora'] ?></td>
                </tr>
            </tbody>
        </table>

        <p>El cual recibo nuevo y en perfecto estado por lo que me hago responsable de las siguientes condiciones:</p>
        <ul>
            <li>En caso de mi retiro de la empresa entregar o transferir el equipo asignado de acuerdo con las condiciones de la entrega.</li>
            <li>En caso de daño, pérdida o extravío asumo mi responsabilidad de acuerdo con el grado de culpa que corresponda y que se proceda a los descuentos o procedimientos que sean necesarios según lo determine la empresa.</li>
            <li>Hacer uso adecuado y para efectos laborales de equipo de dicha marca solamente para uso de herramientas de trabajo y no para otros medios.</li>
        </ul>

        <p>Para los fines que correspondan firmo el <strong><?= date("d/m/Y", strtotime($asignacion['fecha_asignacion'])) ?></strong>.</p>
		


	<div class="row text-center mt-5 d-flex justify-content-between">
    <div class="col-md-6 text-center" style="width: 45%;     margin-top: 50px;">
        <p class="firma-linea mt-4">___________________________</p>
        <p>Firma</p>
    </div>
    <div class="col-md-6 text-center" style="width: 45%;     margin-top: 50px;">
        <p class="firma-linea mt-4">___________________________</p>
        <p># Identidad</p>
    </div>
</div>


        <div class="text-center mt-3 no-print">
            <button class="btn btn-primary" onclick="imprimirHoja()">🖨️ Imprimir</button>
        </div>
    </div>
</body>
</html>

