<?php
require '../conexion.php'; // Conexi�n a la base de datos

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Computadoras_Asignadas.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo utf8_decode("REPORTE DE COMPUTADORAS ASIGNADAS\n\n");

// **Obtener los tipos de componentes disponibles en la base de datos**
$sql_componentes = "SELECT nombre FROM tipos_componentes ORDER BY id";
$result_componentes = $conn->query($sql_componentes);

$tipos_componentes = [];
while ($row = $result_componentes->fetch_assoc()) {
    $tipos_componentes[] = $row['nombre'];
}

// **Encabezados de la tabla**
echo utf8_decode("Empresa\tPlanta\tDepartamento\tAsignado\tRAM\tDisco\tTipo\tMarca\tModelo\tSerie\tSistema Operativo\tProcesador\tA�o");

// Agregar din�micamente los encabezados de los componentes
foreach ($tipos_componentes as $componente) {
    echo utf8_decode("\t$componente (Modelo)\t$componente (Serial)");
}
echo "\n";

// **Consulta para obtener computadoras con sus componentes**
$sql = "SELECT 
    e.nombre AS empresa,
    p.nombre AS planta,
    d.nombre AS departamento,
    u.nombre AS asignado,
    c.ram AS computadora_ram,
    c.disco AS computadora_disco,
    t.tipo AS tipo_computadora,
    m.nombre AS marca,
    c.modelo AS computadora_modelo,
    c.serial AS computadora_serial,
    c.sistema_operativo AS computadora_sistema_operativo,
    c.procesador AS computadora_procesador,
    c.anio AS computadora_anio,
    tc.nombre AS tipo_componente,
    co.modelo AS modelo_componente,
    co.serial AS serial_componente
FROM asignaciones_computadora ac
JOIN computadoras c ON ac.id_computadora = c.id
JOIN usuarios u ON ac.id_usuario = u.usuario
LEFT JOIN departamentos d ON u.departamento_id = d.id
LEFT JOIN plantas p ON ac.planta = p.id
LEFT JOIN empresas e ON p.id_empresa = e.id
LEFT JOIN marcas_computadoras m ON c.id_marca = m.id
LEFT JOIN tipos_computadoras t ON c.id_tipo = t.id
LEFT JOIN asignaciones_componentes acom ON c.id = acom.id_computadora AND acom.activo = 1
LEFT JOIN componentes co ON acom.id_componente = co.id
LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
WHERE ac.activo = 1
ORDER BY e.nombre, p.nombre, u.nombre";  // Ordenado por empresa, planta y usuario

$resultado = $conn->query($sql);
$computadoras = [];

// **Organizar los datos en un array estructurado**
while ($fila = $resultado->fetch_assoc()) {
    $serial = $fila['computadora_serial'];

    if (!isset($computadoras[$serial])) {
        $computadoras[$serial] = [
            'datos' => [
                $fila['empresa'],
                $fila['planta'],
                $fila['departamento'],
                $fila['asignado'],
                $fila['computadora_ram'],
                $fila['computadora_disco'],
                $fila['tipo_computadora'],
                $fila['marca'],
                $fila['computadora_modelo'],
                $fila['computadora_serial'],
                $fila['computadora_sistema_operativo'],
                $fila['computadora_procesador'],
                $fila['computadora_anio']
            ],
            'componentes' => array_fill_keys($tipos_componentes, ["", ""]) // Inicializa todas las columnas vac�as
        ];
    }

    if (!empty($fila['tipo_componente']) && in_array($fila['tipo_componente'], $tipos_componentes)) {
        $computadoras[$serial]['componentes'][$fila['tipo_componente']] = [
            $fila['modelo_componente'],
            $fila['serial_componente']
        ];
    }
}

// **Imprimir los datos ordenados**
foreach ($computadoras as $compu) {
    echo utf8_decode(implode("\t", $compu['datos']));

    foreach ($tipos_componentes as $componente) {
        echo utf8_decode("\t" . implode("\t", $compu['componentes'][$componente]));
    }

    echo "\n";
}

$conn->close();
?>
