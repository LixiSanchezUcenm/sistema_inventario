<?php
include '../conexion.php';

// Encabezados para descargar el archivo Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=historial_asignaciones.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Consulta SQL para obtener los datos
$sql = "SELECT 
            e.nombre AS nombre_empresa,
            pl.nombre AS nombre_planta, 
            p.PDV, 
            p.descripcion AS nombre_pdv,
            u.nombre AS nombre_usuario, 
            u.telefono AS telefono_usuario, 
            u.jefe_inmediato, 
            u.puesto, 
            i.serial AS serie_impresora, 
            i.modelo AS modelo_impresora, 
            m.nombre AS marca_impresora, 
            t.tipo AS tipo_impresora, 
            a.fecha_asignacion, 
            a.asignado_por,
            a.fecha_devolucion
        FROM Asignaciones a
        JOIN Usuarios u ON a.usuario = u.usuario
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Marcas m ON i.id_marca = m.id
        JOIN Tipos_Impresoras t ON i.id_tipo = t.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        JOIN Plantas pl ON p.id_planta = pl.id
        JOIN Empresas e ON pl.id_empresa = e.id
        WHERE a.activo = 1
        ORDER BY a.fecha_asignacion DESC";

$result = $conn->query($sql);

// Verificar si hay datos
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>
            <th>Empresa</th>
            <th>Planta</th>
            <th>Punto de Venta</th>
            <th>Serie</th>
            <th>Modelo</th>
            <th>Marca</th>
            <th>Tipo</th>
            <th>Usuario</th>
            <th>Teléfono</th>
            <th>Jefe Inmediato</th>
            <th>Puesto</th>
            <th>Fecha Asignación</th>
            <th>Asignado Por</th>
            <th>Fecha Devolución</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['nombre_empresa']}</td>
                <td>{$row['nombre_planta']}</td>
                <td>{$row['PDV']} - {$row['nombre_pdv']}</td>
                <td>{$row['serie_impresora']}</td>
                <td>{$row['modelo_impresora']}</td>
                <td>{$row['marca_impresora']}</td>
                <td>{$row['tipo_impresora']}</td>
                <td>{$row['nombre_usuario']}</td>
                <td>{$row['telefono_usuario']}</td>
                <td>{$row['jefe_inmediato']}</td>
                <td>{$row['puesto']}</td>
                <td>{$row['fecha_asignacion']}</td>
                <td>{$row['asignado_por']}</td>
                <td>{$row['fecha_devolucion']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No hay registros disponibles.";
}

$conn->close();
?>
