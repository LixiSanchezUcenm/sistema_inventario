<?php
include '../conexion.php';

// Verificar acceso
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='../dashboard.php';</script>";
    exit();
}

// Agregar tipo de computadora
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar_tipo'])) {
    $tipo = trim($_POST['tipo']); // Se usa 'tipo' en lugar de 'nombre'

    if (!empty($tipo)) {
        $stmt = $conn->prepare("INSERT INTO tipos_computadoras (tipo) VALUES (?)");
        $stmt->bind_param("s", $tipo);
        if ($stmt->execute()) {
            echo "<script>alert('Tipo agregado exitosamente'); window.location.href='menu.php';</script>";
        } else {
            echo "<script>alert('Error al agregar el tipo');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('El campo tipo no puede estar vacío');</script>";
    }
}

// Eliminar tipo
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    $stmt = $conn->prepare("DELETE FROM tipos_computadoras WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Tipo eliminado exitosamente'); window.location.href='menu.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar el tipo');</script>";
    }
    $stmt->close();
}

// Obtener todos los tipos
$result = $conn->query("SELECT * FROM tipos_computadoras");
?>

<div class="container mt-5">
    <h2 class="text-center">Gestión de Tipos de Computadoras</h2>

    <form method="POST" class="mb-3">
        <div class="mb-3">
            <label class="form-label">Tipo de computadora</label>
            <input type="text" name="tipo" class="form-control" required> <!-- Ahora se usa 'tipo' -->
        </div>
        <button type="submit" name="agregar_tipo" class="btn btn-primary">Agregar</button>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo</th> <!-- Cambio en la tabla -->
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['tipo']) ?></td> <!-- Cambio aquí también -->
                <td>
                    <a href="?eliminar=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que deseas eliminar este tipo?')">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
