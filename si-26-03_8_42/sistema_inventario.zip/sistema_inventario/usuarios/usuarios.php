<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Consultar usuarios con los nuevos campos
$query = "SELECT u.usuario, u.nombre, u.rol, u.puesto, u.telefono, u.IMEI, u.jefe_inmediato,
                 d.nombre AS departamento, p.nombre AS planta
          FROM Usuarios u
          LEFT JOIN departamentos d ON u.departamento_id = d.id
          LEFT JOIN plantas p ON u.planta = p.id";

$resultado = mysqli_query($conn, $query);

// Verificar si la consulta es correcta
if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-4">
        <h2 class="text-center">Lista de Usuarios</h2>

        <!-- Input de búsqueda -->
        <input type="text" id="buscador" class="form-control mb-3" placeholder="Buscar en cualquier campo...">

        <a href="crear_usuario.php" class="btn btn-primary mb-3">Agregar Usuario</a>
		        <a href="departamentos.php" class="btn btn-primary mb-3">Agregar departamentos</a>

        <table class="table table-striped" id="tablaUsuarios">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Puesto</th>
                    <th>Teléfono</th>
                    <th>IMEI</th>
                    <th>Jefe Inmediato</th>
                    <th>Departamento</th>
                    <th>Planta</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($resultado)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['usuario']); ?></td>
                        <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($row['rol']); ?></td>
                        <td><?php echo htmlspecialchars($row['puesto']); ?></td>
                        <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                        <td><?php echo htmlspecialchars($row['IMEI']); ?></td>
                        <td><?php echo htmlspecialchars($row['jefe_inmediato']); ?></td>
          <td><?php echo htmlspecialchars(isset($row['departamento']) ? $row['departamento'] : 'No asignado'); ?></td>
          <td><?php echo htmlspecialchars(isset($row['planta']) ? $row['planta'] : 'No asignado'); ?></td>

                        <td>
                            <a href="editar_usuario.php?usuario=<?php echo urlencode($row['usuario']); ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="eliminar_usuario.php?usuario=<?php echo urlencode($row['usuario']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que deseas eliminar este usuario?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        document.getElementById("buscador").addEventListener("keyup", function() {
            let filtro = this.value.toLowerCase();
            let filas = document.querySelectorAll("#tablaUsuarios tbody tr");

            filas.forEach(function(fila) {
                let textoFila = fila.textContent.toLowerCase();
                fila.style.display = textoFila.includes(filtro) ? "" : "none";
            });
        });
    </script>

</body>
</html>
