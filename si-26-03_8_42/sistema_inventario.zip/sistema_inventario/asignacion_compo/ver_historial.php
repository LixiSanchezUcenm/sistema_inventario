<?php
include '../conexion.php'; // Conexión a la base de datos

// Menú header
include '../includes/header.php';

// Verificar que el ID esté presente en la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Error: ID de componente no especificado.');
}

$id_componente = $_GET['id'];

// Obtener el serial del componente antes de buscar en historial_estados_componentes
$query_serial = "SELECT serial FROM componentes WHERE id = ?";
$stmt_serial = $conn->prepare($query_serial);
$stmt_serial->bind_param("i", $id_componente);
$stmt_serial->execute();
$result_serial = $stmt_serial->get_result();
$componente = $result_serial->fetch_assoc();

if (!$componente) {
    die("Error: Componente no encontrado en la base de datos.");
}

$serial = $componente['serial']; // Ahora tenemos el serial correcto

// Consulta para obtener el historial de cambios con el nombre del estado
$query_historial = "
    SELECT e.nombre AS estado_nombre, h.comentario, h.usuario, h.fecha 
    FROM historial_estados_componentes h
    JOIN estados e ON h.nuevo_estado = e.id
    WHERE h.serial = ?
    ORDER BY h.fecha DESC";

$stmt_historial = $conn->prepare($query_historial);
$stmt_historial->bind_param("s", $serial);
$stmt_historial->execute();
$resultado = $stmt_historial->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de Estados del Componente</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1>
        <div class="user-info text-end"></div>
    </header>

    <div class="container mt-4">
        <h2>Historial de Estados del Componente</h2>
        <a href="listar_componentes.php" class="btn btn-secondary">Volver</a>
        
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Estado</th>
                    <th>Comentario</th>
                    <th>Usuario</th>
                    <th>Fecha de Cambio</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($resultado->num_rows > 0): ?>
                    <?php while ($fila = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><span class="badge bg-<?php echo getColorEstado($fila['estado_nombre']); ?>"><?php echo ucfirst($fila['estado_nombre']); ?></span></td>
                            <td><?php echo htmlspecialchars($fila['comentario']); ?></td>
                            <td><?php echo htmlspecialchars($fila['usuario']); ?></td>
                            <td><?php echo htmlspecialchars($fila['fecha']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">No hay historial de cambios para este componente.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>
</body>
</html>

<?php
// Función para asignar color al estado
function getColorEstado($estado) {
    switch (strtolower($estado)) {
        case 'buena':
            return 'success';
        case 'mantenimiento':
            return 'warning';
        case 'robada':
            return 'danger';
        case 'obsoleta':
            return 'secondary';
        default:
            return 'dark';  // Color por defecto si el estado no se encuentra
    }
}
?>
