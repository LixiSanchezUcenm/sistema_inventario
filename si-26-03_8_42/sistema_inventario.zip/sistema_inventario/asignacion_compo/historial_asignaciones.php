<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener el historial de asignaciones de componentes con la computadora asignada
$sql = "SELECT 
            ac.id AS id_asignacion,
            co.serial AS serial_componente,
            co.modelo AS modelo_componente,
            tc.nombre AS tipo_componente,
            c.serial AS serial_computadora,  -- Serial de la computadora asignada
            p.nombre AS nombre_planta,
            ac.fecha_asignacion,
            ac.asignado_por,
            ac.fecha_devolucion
        FROM asignaciones_componentes ac
        JOIN componentes co ON ac.id_componente = co.id
        LEFT JOIN computadoras c ON ac.id_computadora = c.id  -- Relación con computadoras
        LEFT JOIN plantas p ON ac.planta = p.id  
        LEFT JOIN tipos_componentes tc ON co.id_tipo = tc.id
        WHERE ac.activo = 1";

$result = $conn->query($sql);
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Asignaciones de Componentes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	  <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">

</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Historial de Asignaciones de Componentes</h2>
        <input type="text" id="search" class="form-control mb-3" placeholder="Buscar...">

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Serial Componente</th>
                    <th>Modelo</th>
                    <th>Tipo</th>
                    <th>Computadora</th>  <!-- Nueva columna -->
                    <th>Planta</th>
                    <th>Fecha Asignación</th>
                    <th>Asignado Por</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="tableBody">
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['serial_componente']) ?></td>
                        <td><?= htmlspecialchars($row['modelo_componente']) ?></td>
                        <td><?= htmlspecialchars($row['tipo_componente']) ?></td>
                        <td><?= !empty($row['serial_computadora']) ? htmlspecialchars($row['serial_computadora']) : 'No asignada' ?></td> <!-- Nueva celda -->
                        <td><?= htmlspecialchars($row['nombre_planta']) ?></td>
                        <td><?= htmlspecialchars($row['fecha_asignacion']) ?></td>
                        <td><?= htmlspecialchars($row['asignado_por']) ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (empty($row['fecha_devolucion'])) { ?>
                                    <form method="POST" action="finalizar_asignacion.php" class="d-inline">
                                        <input type="hidden" name="id_asignacion" value="<?= $row['id_asignacion'] ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Finalizar</button>
                                    </form>
                                <?php } else { ?>
                                    <span class="text-success">Finalizada</span>
                                <?php } ?>
                                <a href="historial.php?serial=<?= urlencode($row['serial_componente']) ?>" class="btn btn-info btn-sm ms-2">Ver Historial</a>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function () {
            $("#search").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#tableBody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>
