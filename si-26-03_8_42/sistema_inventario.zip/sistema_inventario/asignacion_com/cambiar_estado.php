<?php
include '../conexion.php'; // Conexión a la base de datos
include '../includes/header.php'; // Menú header

// Verificar que el ID de la computadora esté presente en la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Error: ID de computadora no especificado.');
}

$id_computadora = $_GET['id'];

// Obtener los datos actuales de la computadora
$query = "SELECT serial, estado_actual FROM computadoras WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_computadora);
$stmt->execute();
$result = $stmt->get_result();
$computadora = $result->fetch_assoc();

if (!$computadora) {
    die('Error: Computadora no encontrada.');
}

// Obtener lista de estados disponibles
$query_estados = "SELECT id, nombre, permite_asignacion FROM estados";
$result_estados = $conn->query($query_estados);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar Estado de Computadora</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Cambiar Estado de Computadora - <?= htmlspecialchars($computadora['serial']) ?></h2>
    
    <form action="procesar_cambio_computadora.php" method="post">
        <input type="hidden" name="id" value="<?= $id_computadora ?>">

        <div class="mb-3">
            <label for="estado" class="form-label">Nuevo Estado:</label>
            <select name="estado" id="estado" class="form-control" required>
                <?php while ($row = $result_estados->fetch_assoc()) { ?>
                    <option value="<?= $row['id']; ?>" <?= ($row['id'] == $computadora['estado_actual']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($row['nombre']); ?> <?= ($row['permite_asignacion'] == 1) ? "(Asignable)" : "(No asignable)"; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="comentario" class="form-label">Comentario (opcional):</label>
            <textarea name="comentario" id="comentario" class="form-control"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <a href="listar_computadora.php" class="btn btn-secondary">Volver</a>
    </form>
</div>

</body>
</html>
