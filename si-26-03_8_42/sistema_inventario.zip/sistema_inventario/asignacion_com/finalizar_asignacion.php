<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_asignacion'])) {
    $id_asignacion = $_POST['id_asignacion'];
    $fecha_actual = date("Y-m-d H:i:s");

    // Obtener el ID de la computadora asignada
    $sql_get_computadora = "SELECT id_computadora FROM asignaciones_computadora WHERE id = $id_asignacion";
    $result = $conn->query($sql_get_computadora);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_computadora = $row['id_computadora'];

        // Actualizar la asignación de la computadora para marcarla como finalizada
        $sql = "UPDATE asignaciones_computadora SET activo = 0, fecha_devolucion = '$fecha_actual' WHERE id = $id_asignacion";

        if ($conn->query($sql) === TRUE) {
            // Actualizar el estado de la computadora para indicar que ya no está asignada
            $sql_update_computadora = "UPDATE computadoras SET asignada = 0, ubicacion = 'Almacén de IT' WHERE id = $id_computadora";
            $conn->query($sql_update_computadora);

            echo "<script>alert('Asignación de computadora finalizada correctamente'); window.location.href='historial_asignaciones.php';</script>";
        } else {
            echo "<script>alert('Error al finalizar la asignación de computadora'); window.location.href='historial_asignaciones.php';</script>";
        }
    } else {
        echo "<script>alert('No se encontró la computadora asociada'); window.location.href='historial_asignaciones.php';</script>";
    }

    $conn->close();
} else {
    echo "<script>alert('Solicitud no válida'); window.location.href='historial_asignaciones.php';</script>";
}
?>
