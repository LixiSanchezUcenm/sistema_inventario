<?php
include '../conexion.php';

// menu header
include '../includes/header.php';

// Obtener computadoras disponibles (en buen estado y no asignadas)
$sql_computadoras = "SELECT c.id, c.serial, c.modelo 
                     FROM computadoras c
                     JOIN estados e ON c.estado_actual = e.id
                                        WHERE e.permite_asignacion = 1 
                     AND c.asignada = 0";

$result_computadoras = $conn->query($sql_computadoras);

$computadoras = ($result_computadoras->num_rows > 0) ? $result_computadoras->fetch_all(MYSQLI_ASSOC) : [];

// Obtener usuarios
$sql_usuarios = "SELECT usuario, nombre FROM Usuarios";
$result_usuarios = $conn->query($sql_usuarios);

// Obtener plantas
$sql_plantas = "SELECT id, nombre FROM plantas";
$result_plantas = $conn->query($sql_plantas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Computadora</title>
    <link rel="stylesheet" href="../css/estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
</head>
<body>

  <?php include '../includes/navbar.php'; ?>
  
  <div class="container mt-5">
    <h2>Asignar Computadora</h2>
    <form action="procesar_asignacion.php" method="POST">
        <div class="mb-3">
            <label for="computadora" class="form-label">Computadora</label>
            <select class="form-select filtro" name="id_computadora" required>
                <option value="">Seleccione una computadora</option>
                <?php foreach ($computadoras as $row) { ?>
                    <option value="<?= $row['id']; ?>"><?= $row['serial']; ?> - <?= $row['modelo']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="usuario" class="form-label">Usuario</label>
            <select class="form-select filtro" name="usuario" required>
                <option value="">Seleccione un usuario</option>
                <?php while ($row = $result_usuarios->fetch_assoc()) { ?>
                    <option value="<?= $row['usuario']; ?>"><?= $row['nombre']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="planta" class="form-label">Planta</label>
            <select class="form-select filtro" name="planta" required>
                <option value="">Seleccione una planta</option>
                <?php while ($row = $result_plantas->fetch_assoc()) { ?>
                    <option value="<?= $row['id']; ?>"><?= $row['nombre']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="causa_solicitud" class="form-label">Causa de Solicitud</label>
            <textarea class="form-control" name="causa_solicitud" rows="2" placeholder="Ingrese la causa de la solicitud"></textarea>
        </div>

        <div class="mb-3">
            <label for="procedencia" class="form-label">Procedencia</label>
            <input type="text" class="form-control" name="procedencia" placeholder="Ingrese la procedencia del equipo">
        </div>

        <div class="mb-3">
            <label for="observaciones" class="form-label">Observaciones</label>
            <textarea class="form-control" name="observaciones" rows="2" placeholder="Ingrese observaciones adicionales"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Asignar</button>
    </form>
  </div>

  <script>
    $(document).ready(function() {
        $('.filtro').select2({
            width: '100%',
            placeholder: "Escriba para buscar...",
            allowClear: true
        });
    });
  </script>
</body>
</html>
