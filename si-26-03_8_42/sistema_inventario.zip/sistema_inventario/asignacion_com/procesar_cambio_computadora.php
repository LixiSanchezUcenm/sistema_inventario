<?php
session_start();
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_computadora = $_POST['id'];
    $nuevo_estado = $_POST['estado'];
    $comentario = isset($_POST['comentario']) ? $_POST['comentario'] : '';
    $usuario = $_SESSION['usuario'];

    // Actualizar el estado de la computadora
    $query = "UPDATE computadoras SET estado_actual = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $nuevo_estado, $id_computadora);
    $stmt->execute();

    // Guardar en historial
    $query_historial = "INSERT INTO historial_estados_computadoras (serial, nuevo_estado, comentario, usuario) 
                        VALUES ((SELECT serial FROM computadoras WHERE id = ?), ?, ?, ?)";
    $stmt_historial = $conn->prepare($query_historial);
    $stmt_historial->bind_param("isss", $id_computadora, $nuevo_estado, $comentario, $usuario);

    if ($stmt_historial->execute()) {
        header("Location: listar_computadora.php");
        exit();
    } else {
        echo "Error al guardar el historial: " . $stmt_historial->error;
    }
}
?>
