<?php
include '../conexion.php';
include '../includes/header.php';

// Obtener computadoras con su estado, tipo y marca
$query = "SELECT c.id, t.tipo AS tipo_computadora, c.serial, e.nombre AS estado_actual
          FROM computadoras c
          JOIN tipos_computadoras t ON c.id_tipo = t.id
          JOIN estados e ON c.estado_actual = e.id";
$resultado = mysqli_query($conn, $query);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conn));
}

// Obtener los tipos de computadoras para el filtro
$query_tipos = "SELECT * FROM tipos_computadoras";
$resultado_tipos = mysqli_query($conn, $query_tipos);
if (!$resultado_tipos) {
    die("Error al obtener tipos de computadoras: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Computadoras</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	
	    <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
	
</head>
<body>
    <?php include '../includes/navbar.php'; ?>
    <div class="container mt-5">
        <h2>Lista de Computadoras</h2>
        
		     <!-- Botón para ir a conteo_impresoras.php -->
        <div class="text-center my-3">
            <a href="../graficos/conteo_estado.php" class="btn btn-primary">📊 Ver Conteo Detallado</a>
			            <a href="../estado/crud_estado.php" class="btn btn-primary">Nuevos estados</a>

        </div>

		
        <!-- Filtro por tipo de computadora -->
        <div class="row mb-3">
            <div class="col-md-6">
                <select id="tipoComputadoraFilter" class="form-select" onchange="filtrarTabla()">
                    <option value="">Todos los Tipos</option>
                    <?php while ($tipo = mysqli_fetch_assoc($resultado_tipos)): ?>
                        <option value="<?php echo $tipo['tipo']; ?>"><?php echo $tipo['tipo']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-6">
                <input type="text" id="searchInput" class="form-control" placeholder="Buscar por ID, Serial o Estado..." onkeyup="filtrarTabla()">
            </div>
        </div>
        
        <table class="table table-bordered" id="computadorasTable">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Tipo de Computadora</th>
                    <th>Serial</th>
                    <th>Estado Actual</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($computadora = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?php echo $computadora['id']; ?></td>
                    <td><?php echo $computadora['tipo_computadora']; ?></td>
                    <td><?php echo $computadora['serial']; ?></td>
                    <td>
                      <span class="badge bg-<?php echo getColorEstado($computadora['estado_actual']); ?>">
                            <?php echo ucfirst($computadora['estado_actual']); ?>
                        </span>
                    </td>
                    <td>
						    <a href="cambiar_estado.php?id=<?php echo $computadora['id']; ?>" class="btn btn-warning btn-sm">Cambiar Estado</a>
                        <a href="ver_historial.php?id=<?php echo $computadora['id']; ?>" class="btn btn-info btn-sm">Ver Historial</a> <!-- Botón de historial -->
						

                    </td>
					
					
					
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function filtrarTabla() {
            var input = document.getElementById("searchInput").value.toLowerCase();
            var tipoFiltro = document.getElementById("tipoComputadoraFilter").value.toLowerCase();
            var tabla = document.getElementById("computadorasTable");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) {
                var celdas = filas[i].getElementsByTagName("td");
                var mostrar = false;
                
                var id = celdas[0].textContent.toLowerCase();
                var tipo = celdas[1].textContent.toLowerCase();
                var serial = celdas[2].textContent.toLowerCase();
                var estado = celdas[3].textContent.toLowerCase();

                if ((id.includes(input) || tipo.includes(input) || serial.includes(input) || estado.includes(input)) &&
                    (tipoFiltro === "" || tipo.includes(tipoFiltro))) {
                    mostrar = true;
                }

                filas[i].style.display = mostrar ? "" : "none";
            }
        }
    </script>
</body>
</html>

<?php
function getColorEstado($estado) {
    switch (strtolower($estado)) {
        case 'buena': return 'success';
        case 'mantenimiento': return 'warning';
        case 'robada': return 'danger';
        case 'obsoleta': return 'secondary';
        default: return 'dark';
    }
}
?>
