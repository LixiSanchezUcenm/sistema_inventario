<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Verificar conexión
if (!$conn) {
    die("Error en la conexión: " . mysqli_connect_error());
}

// Consulta para obtener los componentes, marcas, tipos y estados
$query = "SELECT 
            Componentes.id, 
            Componentes.serial, 
            Componentes.modelo, 
            Marcas_computadoras.nombre AS marca, 
            Tipos_Componentes.nombre AS tipo, 
            estados.nombre AS estado, 
            IFNULL(Plantas.nombre, 'Almacén de IT') AS ubicacion
          FROM Componentes
          LEFT JOIN Marcas_computadoras ON Componentes.id_marca = Marcas_computadoras.id
          LEFT JOIN Tipos_Componentes ON Componentes.id_tipo = Tipos_Componentes.id
          LEFT JOIN estados ON Componentes.estado_id = estados.id
          LEFT JOIN Plantas ON Componentes.ubicacion = Plantas.id";

$result = mysqli_query($conn, $query);

// Verificar si la consulta se ejecutó correctamente
if (!$result) {
    die("Error en la consulta: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Componentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">Gestión de Componentes</h2>

        <!-- Mostrar cantidad de registros obtenidos -->
        <?php 
        $num_rows = mysqli_num_rows($result);
        echo "<p class='text-center'>Registros encontrados: <strong>$num_rows</strong></p>"; 
        ?>

        <!-- Input de búsqueda -->
        <input type="text" id="buscador" class="form-control mb-3" placeholder="Buscar en cualquier campo...">

        <a href="agregar_componente.php" class="btn btn-success mb-3">Agregar Componente</a>
	  <a href="../gestion_com/nombre_componentes.php" class="btn btn-success mb-3">Agregar Tipos</a>

		

        <table class="table table-bordered" id="tablaComponentes">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Serial</th>
                    <th>Modelo</th>
                    <th>Marca</th>
                    <th>Tipo</th>
                    <th>Estado</th>
                    <th>Ubicación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($num_rows > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['serial'] . "</td>";
                        echo "<td>" . $row['modelo'] . "</td>";
                        echo "<td>" . (isset($row['marca']) ? $row['marca'] : 'Sin marca') . "</td>";
                        echo "<td>" . (isset($row['tipo']) ? $row['tipo'] : 'Sin tipo') . "</td>";
                        echo "<td>" . (isset($row['estado']) ? $row['estado'] : 'Desconocido') . "</td>";
                        echo "<td>" . (isset($row['ubicacion']) ? $row['ubicacion'] : 'No asignado') . "</td>";
                        echo "<td>
                                <a href='editar_componentes.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a>
                                <a href='eliminar_componentes.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"¿Estás seguro de eliminar este componente?\");'>Eliminar</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No hay componentes disponibles</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        // Función de búsqueda en la tabla
        document.getElementById("buscador").addEventListener("keyup", function() {
            let filtro = this.value.toLowerCase();
            let filas = document.querySelectorAll("#tablaComponentes tbody tr");

            filas.forEach(function(fila) {
                let textoFila = fila.textContent.toLowerCase();
                fila.style.display = textoFila.includes(filtro) ? "" : "none";
            });
        });
    </script>

</body>
</html>
