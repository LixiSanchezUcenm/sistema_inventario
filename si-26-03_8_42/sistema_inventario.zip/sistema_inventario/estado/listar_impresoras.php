<?php
include '../conexion.php'; // Asegura que la conexión está bien establecida

// menu header
include '../includes/header.php';

// Consulta para obtener todas las impresoras con su estado actual
$query = "SELECT id, serial, estado_actual FROM impresoras";
$resultado = mysqli_query($conn, $query);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Impresoras</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Menu header -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2>Lista de Impresoras</h2>

        <!-- Botón para ir a conteo_impresoras.php -->
        <div class="text-center my-3">
            <a href="conteo_impresoras.php" class="btn btn-primary">📊 Ver Conteo Detallado</a>
			            <a href="crud_estado.php" class="btn btn-primary">Nuevos estados</a>

        </div>

        <!-- Campo de búsqueda -->
        <input type="text" id="searchInput" class="form-control mb-3" placeholder="Buscar por ID, Serial o Estado..." onkeyup="filtrarTabla()">

        <table class="table table-bordered" id="impresorasTable">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Serial</th>
                    <th>Estado Actual</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($impresora = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?php echo $impresora['id']; ?></td>
                    <td><?php echo $impresora['serial']; ?></td>
                    <td>
                        <span class="badge bg-<?php echo getColorEstado($impresora['estado_actual']); ?>">
                            <?php echo ucfirst($impresora['estado_actual']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="cambiar_estado.php?id=<?php echo $impresora['id']; ?>" class="btn btn-warning btn-sm">Cambiar Estado</a>
                        <a href="ver_historial.php?id=<?php echo urlencode($impresora['id']); ?>" class="btn btn-info btn-sm">Ver Historial</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="../js/bootstrap.bundle.min.js"></script>

    <script>
        function filtrarTabla() {
            var input = document.getElementById("searchInput");
            var filtro = input.value.toLowerCase();
            var tabla = document.getElementById("impresorasTable");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) { // Saltar encabezado
                var celdas = filas[i].getElementsByTagName("td");
                var mostrar = false;

                for (var j = 0; j < celdas.length - 1; j++) { // No filtrar por acciones
                    if (celdas[j].textContent.toLowerCase().includes(filtro)) {
                        mostrar = true;
                        break;
                    }
                }

                filas[i].style.display = mostrar ? "" : "none";
            }
        }
    </script>
</body>
</html>

<?php
// Función para definir los colores según el estado
function getColorEstado($estado) {
    switch ($estado) {
        case 'buena': return 'success';
        case 'mantenimiento': return 'warning';
        case 'robada': return 'danger';
        case 'obsoleta': return 'secondary';
        default: return 'dark';
    }
}
?>
