<?php
include_once __DIR__ . '/../conexion.php';

if (isset($_FILES["archivo_csv"])) {
    $archivo = $_FILES["archivo_csv"]["tmp_name"];
    
    $handle = fopen($archivo, "r");

    if ($handle !== FALSE) {
        fgetcsv($handle, 1000, ";"); // Saltar encabezados

        while (($datos = fgetcsv($handle, 1000, ";")) !== FALSE) {
            // Verificar que la fila tiene al menos 2 columnas
            if (count($datos) < 2) {
                continue; // Saltar filas incompletas
            }

            // Evitar errores con valores vacíos
            $nombre = isset($datos[0]) ? $conn->real_escape_string(trim($datos[0])) : '';
            $id_empresa = isset($datos[1]) ? intval($datos[1]) : 0;

            // Verificar que los datos sean válidos antes de insertar
            if (!empty($nombre) && $id_empresa > 0) {
                $sql = "INSERT INTO plantas (nombre, id_empresa) VALUES ('$nombre', $id_empresa)";
                $conn->query($sql);
            }
        }
        fclose($handle);
        echo "Datos importados correctamente.";
    } else {
        echo "Error al abrir el archivo.";
    }
}

$conn->close();
?>
