<?php
include '../conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['archivo_csv']) && $_FILES['archivo_csv']['error'] == 0) {
        $archivo = $_FILES['archivo_csv']['tmp_name'];
        $handle = fopen($archivo, "r");

        // Omitir la primera línea (encabezados)
        fgetcsv($handle, 1000, ";");

        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $serial = mysqli_real_escape_string($conn, $data[0]);
            $modelo = mysqli_real_escape_string($conn, $data[1]);
            $id_marca = intval($data[2]);
            $id_tipo = intval($data[3]);

            // Verificar si la impresora ya existe por serial
            $check = mysqli_query($conn, "SELECT * FROM Impresoras WHERE serial = '$serial'");
            if (mysqli_num_rows($check) == 0) {
                $query = "INSERT INTO Impresoras (serial, modelo, id_marca, id_tipo) 
                          VALUES ('$serial', '$modelo', '$id_marca', '$id_tipo')";
                mysqli_query($conn, $query);
            }
        }

        fclose($handle);
        echo "<script>alert('Impresoras importadas exitosamente'); window.location.href='importar.php';</script>";
    } else {
        echo "<script>alert('Error: No se recibió ningún archivo'); window.location.href='importar.php';</script>";
    }
}
?>
