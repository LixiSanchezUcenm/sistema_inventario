<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['archivo_csv']) && $_FILES['archivo_csv']['error'] == 0) {
        $archivo = $_FILES['archivo_csv']['tmp_name'];
        $handle = fopen($archivo, "r");

        // Omitir la primera línea (encabezados)
        fgetcsv($handle, 1000, ";");

        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $usuario = mysqli_real_escape_string($conn, trim($data[0]));
            $nombre = mysqli_real_escape_string($conn, trim($data[1]));
            $contrasena = password_hash(trim($data[2]), PASSWORD_DEFAULT);
            $rol = mysqli_real_escape_string($conn, trim($data[3]));
            $puesto = mysqli_real_escape_string($conn, trim($data[4]));
            $telefono = mysqli_real_escape_string($conn, trim($data[5]));
            $imei = mysqli_real_escape_string($conn, trim($data[6]));
            $jefe = mysqli_real_escape_string($conn, trim($data[7]));
            $departamento_id = intval($data[8]);
            $planta = intval($data[9]);

            // Llamar al procedimiento almacenado
            $query = "CALL ImportarUsuario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "ssssssssii", $usuario, $nombre, $contrasena, $rol, $puesto, $telefono, $imei, $jefe, $departamento_id, $planta);

            if (!mysqli_stmt_execute($stmt)) {
                echo "<script>alert('Error al importar el usuario $usuario: " . mysqli_error($conn) . "');</script>";
            } else {
                echo "<script>alert('Usuario $usuario importado exitosamente.');</script>";
            }

            mysqli_stmt_close($stmt);
        }

        fclose($handle);
        echo "<script>alert('Importación de usuarios completada.'); window.location.href='usuarios.php';</script>";
    } else {
        echo "<script>alert('Error: No se recibió ningún archivo'); window.location.href='importar.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importar Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../styles.css">
</head>
<body class="bg-light">
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center">Importar Usuarios desde CSV</h2>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Seleccione un archivo CSV</h5>
                        <form action="importar_usuarios.php" method="POST" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-3" name="archivo_csv" accept=".csv" required>
                            <button type="submit" class="btn btn-primary w-100">Importar</button>
                        </form>
                        <p class="mt-3 text-muted"><strong>Formato esperado:</strong> usuario; nombre; contraseña; rol; puesto; teléfono; IMEI; jefe inmediato; departamento_id; planta_id</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
