<?php
include '../conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['archivo_csv']) && $_FILES['archivo_csv']['error'] == 0) {
        $archivo = $_FILES['archivo_csv']['tmp_name'];
        $handle = fopen($archivo, "r");

        // Omitir la primera línea (encabezados)
        fgetcsv($handle, 1000, ";");

        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $serial = mysqli_real_escape_string($conn, trim($data[0]));
            $modelo = mysqli_real_escape_string($conn, trim($data[1]));
            $id_marca = intval($data[2]);
            $id_tipo = intval($data[3]);

            // Definir valores predeterminados
            $ubicacion = 'Almacén IT';
            $estado_id = 1; // Se asume que el estado 'Buena' tiene ID 1
            $asignada = 0;

            // Verificar si el componente ya existe por serial
            $check = mysqli_query($conn, "SELECT id FROM componentes WHERE serial = '$serial'");
            if (mysqli_num_rows($check) == 0) {
                $query = "INSERT INTO componentes (serial, modelo, id_marca, id_tipo, ubicacion, estado_id, asignada) 
                          VALUES ('$serial', '$modelo', $id_marca, $id_tipo, '$ubicacion', $estado_id, $asignada)";
                mysqli_query($conn, $query);
            }
        }

        fclose($handle);
        echo "<script>alert('Componentes importados exitosamente'); window.location.href='importar.php';</script>";
    } else {
        echo "<script>alert('Error: No se recibió ningún archivo'); window.location.href='importar.php';</script>";
    }
}
?>
