<?php include '../includes/header.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importar CSV</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../styles.css">
</head>
<body class="bg-light">
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center mb-4 text-primary">Importación de Datos</h2>

        <div class="row justify-content-center">
            <!-- Importar Plantas -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Importar Plantas</h5>
                        <form action="procesar_importacion.php" method="post" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-2" name="archivo_csv" accept=".csv" required>
                            <button type="submit" class="btn btn-primary w-100">Importar</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Importar Impresoras -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Importar Impresoras</h5>
                        <form action="importar_impresoras.php" method="POST" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-2" name="archivo_csv" accept=".csv" required>
                            <button type="submit" class="btn btn-success w-100">Importar</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Importar Computadoras -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Importar Computadoras</h5>
                        <form action="importar_computadoras.php" method="POST" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-2" name="archivo_csv" required>
                            <button type="submit" class="btn btn-primary w-100">Importar</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Importar Componentes -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Importar Componentes</h5>
                        <form action="importar_componentes.php" method="POST" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-2" name="archivo_csv" required>
                            <button type="submit" class="btn btn-primary w-100">Subir</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Importar Usuarios -->
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Importar Usuarios</h5>
                        <form action="importar_usuarios.php" method="POST" enctype="multipart/form-data">
                            <input type="file" class="form-control mb-2" name="archivo_csv" required>
                            <button type="submit" class="btn btn-primary w-100">Subir</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
