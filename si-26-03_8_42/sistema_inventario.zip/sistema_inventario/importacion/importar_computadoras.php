<?php
include '../conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['archivo_csv']) && $_FILES['archivo_csv']['error'] == 0) {
        $archivo = $_FILES['archivo_csv']['tmp_name'];
        $handle = fopen($archivo, "r");

        // Omitir la primera línea (encabezados)
        fgetcsv($handle, 1000, ";");

        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
            $serial = mysqli_real_escape_string($conn, trim($data[0]));
            $modelo = mysqli_real_escape_string($conn, trim($data[1]));
            $id_marca = intval($data[2]);
            $id_tipo = intval($data[3]);
            $disco = mysqli_real_escape_string($conn, trim($data[4]));
            $ram = mysqli_real_escape_string($conn, trim($data[5]));
            $procesador = mysqli_real_escape_string($conn, trim($data[6]));
            $sistema_operativo = mysqli_real_escape_string($conn, trim($data[7]));
            $anio = intval($data[8]);

            // Verificar si la computadora ya existe por serial
            $check = mysqli_query($conn, "SELECT * FROM computadoras WHERE serial = '$serial'");
            if (mysqli_num_rows($check) == 0) {
                // Insertar la computadora en la base de datos
                $query = "INSERT INTO computadoras (serial, modelo, id_marca, id_tipo, disco, ram, procesador, sistema_operativo, estado_actual, ubicacion, anio) 
                          VALUES ('$serial', '$modelo', '$id_marca', '$id_tipo', '$disco', '$ram', '$procesador', '$sistema_operativo', 1, 'Almacén IT', '$anio')";
                mysqli_query($conn, $query);
            }
        }

        fclose($handle);
        echo "<script>alert('Computadoras importadas exitosamente'); window.location.href='importar.php';</script>";
    } else {
        echo "<script>alert('Error: No se recibió ningún archivo'); window.location.href='importar.php';</script>";
    }
}
?>
