<?php
include '../conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_impresora = $_POST['id_impresora'];
    $usuario = $_POST['usuario'];
    $PDV = $_POST['PDV'];
    $asignado_por = $_SESSION['usuario']; // Usuario que está asignando

    // Verificar que la impresora no esté asignada
    $sql_check = "SELECT asignada FROM Impresoras WHERE id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("i", $id_impresora);
    $stmt_check->execute();
    $stmt_check->bind_result($asignada);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($asignada) {
        echo "<script>alert('La impresora ya está asignada.'); window.location.href='asignar.php';</script>";
        exit();
    }

    // Insertar en Asignaciones
    $sql = "INSERT INTO Asignaciones (id_impresora, usuario, PDV, asignado_por) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $id_impresora, $usuario, $PDV, $asignado_por);

    if ($stmt->execute()) {
        // Actualizar el estado de la impresora a asignada
        $sql_update = "UPDATE Impresoras SET ubicacion = ?, asignada = 1 WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("si", $PDV, $id_impresora);
        $stmt_update->execute();
        
        // Redirigir con mensaje de éxito
        echo "<script>alert('Impresora asignada correctamente.'); window.location.href='asignar.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error al asignar la impresora.'); window.location.href='asignar.php';</script>";
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
