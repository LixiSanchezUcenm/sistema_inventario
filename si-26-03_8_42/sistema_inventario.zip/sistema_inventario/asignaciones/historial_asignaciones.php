<?php
include '../conexion.php';

// menu header
include '../includes/header.php';

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL con la empresa incluida
$sql = "SELECT 
            a.id AS id_asignacion,
            e.nombre AS nombre_empresa,
            pl.nombre AS nombre_planta, 
            p.PDV, 
            p.descripcion AS nombre_pdv,
            u.nombre AS nombre_usuario, 
            u.telefono AS telefono_usuario, 
            u.jefe_inmediato, 
            u.puesto, 
            i.serial AS serie_impresora, 
            i.modelo AS modelo_impresora, 
            m.nombre AS marca_impresora, 
            t.tipo AS tipo_impresora, 
            a.fecha_asignacion, 
            a.asignado_por,
            a.fecha_devolucion
        FROM Asignaciones a
        JOIN Usuarios u ON a.usuario = u.usuario
        JOIN Impresoras i ON a.id_impresora = i.id
        JOIN Marcas m ON i.id_marca = m.id
        JOIN Tipos_Impresoras t ON i.id_tipo = t.id
        JOIN Puntos_venta p ON a.PDV = p.PDV
        JOIN Plantas pl ON p.id_planta = pl.id
        JOIN Empresas e ON pl.id_empresa = e.id
        WHERE a.activo = 1
        ORDER BY a.fecha_asignacion DESC";

$result = $conn->query($sql);

// Verificar si la consulta tuvo errores
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Asignaciones</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
	
</head>
<body>

    <!-- Menu header -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Historial de Asignaciones</h2>

        <input type="text" id="search" class="form-control mb-3" placeholder="Buscar en cualquier campo...">
		

        <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
            <table class="table table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Empresa</th>
                        <th>Planta</th>
                        <th>Punto de Venta</th>
                        <th>Serie</th>
                        <th>Modelo</th>
                        <th>Marca</th>
                        <th>Tipo</th>
                        <th>Usuario</th>
                        <th>Teléfono</th>
                        <th>Jefe Inmediato</th>
                        <th>Puesto</th>
                        <th>Fecha Asignación</th>
                        <th>Asignado Por</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nombre_empresa']) ?></td>
                            <td><?= htmlspecialchars($row['nombre_planta']) ?></td>
                            <td><?= htmlspecialchars($row['PDV']) ?> - <?= htmlspecialchars($row['nombre_pdv']) ?></td>
                            <td><?= htmlspecialchars($row['serie_impresora']) ?></td>
                            <td><?= htmlspecialchars($row['modelo_impresora']) ?></td>
                            <td><?= htmlspecialchars($row['marca_impresora']) ?></td>
                            <td><?= htmlspecialchars($row['tipo_impresora']) ?></td>
                            <td><?= htmlspecialchars($row['nombre_usuario']) ?></td>
                            <td><?= htmlspecialchars($row['telefono_usuario']) ?></td>
                            <td><?= htmlspecialchars($row['jefe_inmediato']) ?></td>
                            <td><?= htmlspecialchars($row['puesto']) ?></td>
                            <td><?= htmlspecialchars($row['fecha_asignacion']) ?></td>
                            <td><?= htmlspecialchars($row['asignado_por']) ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if (empty($row['fecha_devolucion'])) { ?>
                                        <form method="POST" action="finalizar_asignacion.php" class="d-inline">
                                            <input type="hidden" name="id_asignacion" value="<?= $row['id_asignacion'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Finalizar</button>
                                        </form>
                                    <?php } else { ?>
                                        <span class="text-success">Finalizada</span>
                                    <?php } ?>
                                    <a href="historial.php?serial=<?= urlencode($row['serie_impresora']) ?>" class="btn btn-info btn-sm ms-2">Asignaciones</a>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#search").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#tableBody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>
