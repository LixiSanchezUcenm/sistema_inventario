<?php
session_start();
include '../conexion.php';


// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    echo "<script>alert('Debes iniciar sesión primero'); window.location.href='../login.php';</script>";
    exit();
}

$usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'];

// Si el usuario tiene rol "sin acceso", lo redirigimos al login con un mensaje
if ($rol == 'sin acceso') {
    echo "<script>alert('No tienes permiso para acceder al sistema.'); window.location.href='../login.php';</script>";
    exit();
}
?>
