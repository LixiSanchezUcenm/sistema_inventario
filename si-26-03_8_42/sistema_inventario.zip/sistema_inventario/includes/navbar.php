
 <!-- Encabezado con colores personalizados -->
    <header class="header d-flex align-items-center justify-content-between">
        <h1 class="ms-3">Sistema de Inventario</h1> 
        <div class="user-info text-end">
        
        </div>
    </header>


 <!-- Menú de navegación horizontal con logo -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="../dashboard.php">
				<img src="../logo.png" alt="Logo" class="logo me-2">
          
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
              
				<span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
						
						
						
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Gestion de Impresoras</a>
         
						<ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="../asignaciones/asignar.php">Gestión de Asignaciones</a></li>
                <li><a class="dropdown-item" href="../asignaciones/historial_asignaciones.php">Historial de Asignaciones</a></li>
                            <li><a class="dropdown-item" href="../estado/listar_impresoras.php">Estado Impresoras</a></li>
							
							<li class="nav-item">
                            <a href="../admin/crud_impresoras.php" class="nav-link">Registro Impresoras</a>
                        </li>
							
							
                        </ul>
                    </li>
					


				
				 <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración Computadoras</a>
                           
					 <ul class="dropdown-menu">
					<li><a class="dropdown-item" href="../computadoras/crud_computadoras.php">Agregar Computadoras</a></li>
   <li><a class="dropdown-item" href="../asignacion_com/asignar_computadora.php">asignar computadora Computadoras</a></li>
			<li><a class="dropdown-item" href="../asignacion_com/listar_computadora.php">estado Computadoras</a></li>
			<li><a class="dropdown-item" href="../asignacion_com/historial_asignaciones.php">historial</a></li>

                            </ul>
                        </li>
		
					
					
					
				 <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración Componentes</a>
                            
					 <ul class="dropdown-menu">
			  <li><a class="dropdown-item" href="../componentes/crud_componentes.php">Agregar Componentes</a></li>
				<li><a class="dropdown-item" href="../asignacion_compo/asignacion_componentes.php">asignar componentes</a></li>
			<li><a class="dropdown-item" href="../asignacion_compo/listar_componentes.php">estado componentes</a></li>
			<li><a class="dropdown-item" href="../asignacion_compo/historial_asignaciones.php">historial</a></li>

                            </ul>
                        </li>
					
				
					
					  <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Reportes</a>
                            
						  <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../reportes/listar_asignaciones.php">Computadora</a></li>
                                <li><a class="dropdown-item" href="../reportes/asignacion_impresoras.php">Impresoras</a></li>		
                            </ul>		
                        </li>
					
				

                    <?php if ($rol == 'administrador') : ?>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Configuración</a>
                          
							<ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../empresa/menu.php">Empresa</a></li>
                                <li><a class="dropdown-item" href="../gestion_mt/menu.php">Impresoras</a></li>	
					  <li><a class="dropdown-item" href="../gestion_com/menu.php">Computadoras y Componentes</a></li>		

					     <li><a class="dropdown-item" href="../importacion/procesar_importacion.php">Importaciones</a></li>		
								
                            </ul>		
                        </li>
					
					
                        <li class="nav-item">
                            <a href="../usuarios/usuarios.php" class="nav-link">Gestión de Usuarios</a>
                        </li>
					
					
                    <?php endif; ?>

                    <li class="nav-item">
                        <a href="../logout.php" class="nav-link text-danger">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
