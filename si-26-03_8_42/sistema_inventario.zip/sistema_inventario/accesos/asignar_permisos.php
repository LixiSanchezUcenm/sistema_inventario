<?php
include '../conexion.php';

// Verificar acceso solo para administradores
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Obtener el rol ID
if (isset($_POST['rol_id'])) {
    $rol_id = $_POST['rol_id'];

    // Eliminar permisos existentes
    $conn->query("DELETE FROM permisos WHERE rol_id = $rol_id");

    // Asignar los nuevos permisos
    if (isset($_POST['modulos'])) {
        foreach ($_POST['modulos'] as $modulo_id) {
            $tiene_permiso = 1; // Habilitar permiso
            $sql = "INSERT INTO permisos (rol_id, modulo_id, tiene_permiso) VALUES ($rol_id, $modulo_id, $tiene_permiso)";
            $conn->query($sql);
        }
    }

    echo "<script>alert('Permisos actualizados exitosamente'); window.location.href='roles.php?editar=$rol_id';</script>";
} else {
    echo "<script>alert('Rol no especificado'); window.location.href='roles.php';</script>";
}
?>
