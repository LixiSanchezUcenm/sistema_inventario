<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar acceso solo para administradores
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Obtener el rol seleccionado
if (isset($_GET['rol_id'])) {
    $rol_id = $_GET['rol_id'];
} else {
    echo "<script>alert('No se ha seleccionado un rol.'); window.location.href='roles.php';</script>";
    exit();
}

// Obtener todos los módulos
$query_modulos = "SELECT * FROM modulos";
$modulos_result = $conn->query($query_modulos);

// Obtener los permisos actuales del rol
$query_permisos = "SELECT * FROM permisos WHERE rol_id = $rol_id";
$permisos_result = $conn->query($query_permisos);
$permisos = [];
while ($row = $permisos_result->fetch_assoc()) {
    $permisos[$row['modulo_id']] = $row['tiene_acceso'];
}

// Procesar el formulario de actualización de permisos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Iterar sobre los módulos y actualizar los permisos
    foreach ($modulos_result as $modulo) {
        $modulo_id = $modulo['id'];
        $tiene_acceso = isset($_POST['modulo_' . $modulo_id]) ? 1 : 0;

        // Verificar si ya existe un registro de permisos
        $check_permiso = $conn->query("SELECT * FROM permisos WHERE rol_id = $rol_id AND modulo_id = $modulo_id");
        if ($check_permiso->num_rows > 0) {
            // Si el permiso ya existe, actualizarlo
            $conn->query("UPDATE permisos SET tiene_acceso = $tiene_acceso WHERE rol_id = $rol_id AND modulo_id = $modulo_id");
        } else {
            // Si no existe, insertar un nuevo permiso
            $conn->query("INSERT INTO permisos (rol_id, modulo_id, tiene_acceso) VALUES ($rol_id, $modulo_id, $tiene_acceso)");
        }
    }
    // Redirigir a roles.php después de la actualización
    echo "<script>alert('Permisos actualizados exitosamente'); window.location.href='roles.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Permisos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="header d-flex align-items-center justify-content-between p-3 bg-primary text-white">
        <h1 class="ms-3">Sistema de Inventario</h1>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Permisos para el Rol</h2>

        <form method="POST">
            <h4>Selecciona los módulos a los que tiene acceso el rol:</h4>
            <div class="mb-3">
                <?php while ($modulo = $modulos_result->fetch_assoc()): ?>
                    <div class="form-check">
                        <input 
                            class="form-check-input" 
                            type="checkbox" 
                            name="modulo_<?= $modulo['id'] ?>" 
                            value="1" 
                            <?= isset($permisos[$modulo['id']]) && $permisos[$modulo['id']] == 1 ? 'checked' : '' ?>>
                        <label class="form-check-label" for="modulo_<?= $modulo['id'] ?>">
                            <?= $modulo['nombre'] ?>
                        </label>
                    </div>
                <?php endwhile; ?>
            </div>
            <button type="submit" class="btn btn-primary" id="update-permissions-btn">Actualizar Permisos</button>
        </form>
    </div>

    <script>
        // Este script redirige a roles.php después de que el formulario es enviado correctamente
        document.getElementById('update-permissions-btn').addEventListener('click', function() {
            setTimeout(function() {
                window.location.href = 'roles.php';
            }, 500); // Espera medio segundo para asegurar que el formulario se haya enviado
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
