<?php
include '../conexion.php';
include '../includes/header.php';

// Verificar acceso solo para administradores
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 'administrador') {
    echo "<script>alert('Acceso denegado'); window.location.href='dashboard.php';</script>";
    exit();
}

// Obtener todos los módulos
$modulos = $conn->query("SELECT * FROM modulos");

// Crear un nuevo rol
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_GET['editar'])) {
    $nombre = $_POST['nombre'];
    $sql = "INSERT INTO roles (nombre) VALUES ('$nombre')";
    if ($conn->query($sql)) {
        echo "<script>alert('Rol agregado exitosamente'); window.location.href='roles.php';</script>";
    } else {
        echo "<script>alert('Error al agregar rol'); window.location.href='roles.php';</script>";
    }
}

// Editar un rol existente
if (isset($_GET['editar'])) {
    $id = $_GET['editar'];
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre = $_POST['nombre'];
        $sql = "UPDATE roles SET nombre='$nombre' WHERE id=$id";
        if ($conn->query($sql)) {
            echo "<script>alert('Rol actualizado exitosamente'); window.location.href='roles.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar rol'); window.location.href='roles.php';</script>";
        }
    }
    $result = $conn->query("SELECT * FROM roles WHERE id=$id");
    $role = $result->fetch_assoc();
}

// Eliminar un rol
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM roles WHERE id=$id";
    $conn->query($sql);
}

// Obtener todos los roles
if (!isset($_GET['editar'])) {
    $result = $conn->query("SELECT * FROM roles");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Roles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header class="header d-flex align-items-center justify-content-between p-3 bg-primary text-white">
        <h1 class="ms-3">Sistema de Inventario</h1>
    </header>
    
    <div class="container mt-5">
        <a href="roles.php" class="btn btn-primary mb-3">Roles</a>
        <a href="modulos.php" class="btn btn-primary mb-3">Módulos</a>
        <a href="permisos.php" class="btn btn-primary mb-3">Permisos</a>

        <h2 class="text-center">Gestión de Roles</h2>

        <?php if (isset($_GET['editar'])): ?>
        <!-- Formulario para editar solo el nombre del rol -->
        <form method="POST" class="mb-3">
            <div class="mb-3">
                <label class="form-label">Nombre del Rol</label>
                <input type="text" name="nombre" class="form-control" value="<?= $role['nombre'] ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
        <?php else: ?>
        <!-- Formulario para agregar un nuevo rol -->
        <form method="POST" class="mb-3">
            <div class="mb-3">
                <label class="form-label">Nombre del Rol</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Agregar</button>
        </form>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['nombre'] ?></td>
                    <td>
                        <a href="?editar=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                        <a href="?eliminar=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que deseas eliminar este rol?')">Eliminar</a>
                        <a href="permisos.php?rol_id=<?= $row['id'] ?>" class="btn btn-info btn-sm">Permisos</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
