<?php
include '../conexion.php';

// Crear módulo
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['crear'])) {
    $nombre = $_POST['nombre'];
    $archivo_php = $_POST['archivo_php'];
    $sql = "INSERT INTO modulos (nombre, archivo_php) VALUES ('$nombre', '$archivo_php')";
    
    if ($conn->query($sql)) {
        echo "<div class='alert alert-success'>Módulo agregado con éxito.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error al agregar módulo: " . $conn->error . "</div>";
    }
}

// Editar módulo
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $archivo_php = $_POST['archivo_php'];

    $sql = "UPDATE modulos SET nombre = '$nombre', archivo_php = '$archivo_php' WHERE id = $id";

    if ($conn->query($sql)) {
        echo "<div class='alert alert-success'>Módulo actualizado con éxito.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error al actualizar el módulo: " . $conn->error . "</div>";
    }
}

// Eliminar módulo
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM modulos WHERE id = $id";

    if ($conn->query($sql)) {
        echo "<div class='alert alert-success'>Módulo eliminado con éxito.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar el módulo: " . $conn->error . "</div>";
    }
}

// Obtener todos los módulos
$result = $conn->query("SELECT * FROM modulos");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Módulos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header d-flex align-items-center justify-content-between p-3 bg-primary text-white">
        <h1 class="ms-3">Sistema de Inventario</h1>
    </header>

    <div class="container mt-5">
        <h2 class="text-center">Gestión de Módulos</h2>

        <a href="roles.php" class="btn btn-primary mb-3">Roles</a>
        <a href="modulos.php" class="btn btn-primary mb-3">Módulos</a>
        <a href="permisos.php" class="btn btn-primary mb-3">Permisos</a>

        <!-- Formulario de crear módulo -->
        <h3>Agregar Módulo</h3>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Módulo</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="archivo_php" class="form-label">Archivo PHP</label>
                <input type="text" name="archivo_php" class="form-control" required>
            </div>
            <button type="submit" name="crear" class="btn btn-primary">Agregar</button>
        </form>

        <hr>

        <h3>Lista de Módulos</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Archivo PHP</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['nombre'] ?></td>
                        <td><?= $row['archivo_php'] ?></td>
                        <td>
                            <!-- Editar módulo -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editarModal<?= $row['id'] ?>">Editar</button>
                            <!-- Eliminar módulo -->
                            <a href="?eliminar=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que deseas eliminar este módulo?')">Eliminar</a>
                        </td>
                    </tr>

                    <!-- Modal para editar el módulo -->
                    <div class="modal fade" id="editarModal<?= $row['id'] ?>" tabindex="-1" aria-labelledby="editarModalLabel<?= $row['id'] ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editarModalLabel<?= $row['id'] ?>">Editar Módulo</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form method="POST" action="">
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <div class="mb-3">
                                            <label for="nombre" class="form-label">Nombre del Módulo</label>
                                            <input type="text" name="nombre" class="form-control" value="<?= $row['nombre'] ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="archivo_php" class="form-label">Archivo PHP</label>
                                            <input type="text" name="archivo_php" class="form-control" value="<?= $row['archivo_php'] ?>" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" name="editar" class="btn btn-primary">Actualizar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
