<?php
include '../conexion.php';

if (!isset($_GET['id'])) {
    echo "ID de impresora no proporcionado.";
    exit;
}

$id = $_GET['id'];

// Eliminar la impresora de la base de datos
$query = "DELETE FROM Computadoras WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: crud_computadoras.php?mensaje=Computadora eliminada correctamente");
    exit;
} else {
    echo "Error al eliminar la computadora.";
}
?>
