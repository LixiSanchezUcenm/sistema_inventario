<?php
include '../conexion.php'; // Conexión a la base de datos


// Insertar una nueva empresas
if (isset($_POST['agregar_empresas'])) {
    $nombre_empresas = $_POST['nombre_empresas'];
    $query = "INSERT INTO empresas (nombre) VALUES ('$nombre_empresas')";
    mysqli_query($conn, $query);
    header('Location: menu.php');
}



// Eliminar una empresas
if (isset($_GET['eliminar_empresas'])) {
    $id = $_GET['eliminar_empresas'];
    $query = "DELETE FROM empresas WHERE id = $id";
    mysqli_query($conn, $query);
    header('Location: menu.php');
}


?>

<div class="container mt-4">
    <h2>Gestión de empresass y Tipos de Impresoras</h2>
    <div class="row">
        <div class="col-md-6">
            <h4>Agregar empresas</h4>
            <form method="POST">
                <input type="text" name="nombre_empresas" class="form-control mb-2" placeholder="Nombre de la empresas" required>
                <button type="submit" name="agregar_empresas" class="btn btn-primary">Agregar</button>
            </form>
        </div>
       
    </div>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <h4>Lista de empresass</h4>
            <table class="table table-bordered">
                <thead><tr><th>ID</th><th>Nombre</th><th>Acción</th></tr></thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM empresas");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['nombre']}</td>
                            <td><a href='empresas.php?eliminar_empresas={$row['id']}' class='btn btn-danger btn-sm'>Eliminar</a></td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        
    </div>
</div>


