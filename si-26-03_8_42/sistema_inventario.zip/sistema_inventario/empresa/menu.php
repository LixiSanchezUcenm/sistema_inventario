<?php
ob_start(); // Inicia el buffer de salida
include '../conexion.php';
include '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Ubicaciones</title>
    
    <!-- Bootstrap CSS (solo una vez) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="../styles.css">
</head>
<body>

    <!-- Menú de navegación -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-4">
        <h2 class="text-center">Gestión de empresas, Plantas, Tiendas y Puntos de Venta</h2>
        
        <!-- Pestañas -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="empresas-tab" data-bs-toggle="tab" data-bs-target="#empresas" type="button" role="tab">Empresas</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="plantas-tab" data-bs-toggle="tab" data-bs-target="#plantas" type="button" role="tab">Plantas</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="puntos-tab" data-bs-toggle="tab" data-bs-target="#puntos" type="button" role="tab">Puntos de Venta</button>
            </li>
        </ul>
        
        <div class="tab-content mt-3" id="myTabContent">
            <!-- Empresas -->
            <div class="tab-pane fade show active" id="empresas" role="tabpanel">
                <?php include '../empresa/empresas.php'; ?>
            </div>
            <!-- Plantas -->
            <div class="tab-pane fade" id="plantas" role="tabpanel">
                <?php include '../empresa/plantas.php'; ?>
            </div>
            <!-- Puntos de Venta -->
            <div class="tab-pane fade" id="puntos" role="tabpanel">
                <?php include '../empresa/puntos.php'; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (solo una vez y antes de cerrar <body>) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
