<?php
include '../conexion.php';

// Obtener plantas para el selector
$plantas = mysqli_query($conn, "SELECT * FROM Plantas");




// Agregar planta
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar_punto'])) {
    $PDV = $_POST['PDV'];
    $descripcion = $_POST['descripcion'];

    $id_planta = $_POST['id_planta'];
    $sql = "INSERT INTO puntos_venta (PDV, descripcion, id_planta) VALUES ('$PDV', '$descripcion', $id_planta)";
    mysqli_query($conn, $sql);
}


// Eliminar punto de venta
if (isset($_GET['eliminar'])) {
    $PDV = mysqli_real_escape_string($conn, $_GET['eliminar']);
    $sql = "DELETE FROM Puntos_venta WHERE PDV = '$PDV'";
    mysqli_query($conn, $sql);
    header('Location: menu.php');
    exit();
}



// Obtener puntos de venta con su planta
$puntos = mysqli_query($conn, "SELECT Puntos_venta.PDV, Puntos_venta.descripcion, Plantas.nombre AS planta FROM Puntos_venta INNER JOIN Plantas ON Puntos_venta.id_planta = Plantas.id");
?>

<div class="container">
    <h3>Puntos de Venta</h3>
    <form method="POST" class="mb-3">
        <div class="input-group">
            <input type="text" name="PDV" class="form-control" placeholder="Código PDV" required>
            <input type="text" name="descripcion" class="form-control" placeholder="Descripción" required>
            <select name="id_planta" class="form-select" required>
                <option value="" disabled selected>Seleccionar Planta</option>
                <?php while ($planta = mysqli_fetch_assoc($plantas)) : ?>
                    <option value="<?= $planta['id'] ?>"><?= $planta['nombre'] ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" name="agregar_punto" class="btn btn-success">Agregar</button>
			
			
			
			
        </div>
    </form>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Código PDV</th>
                <th>Descripción</th>
                <th>Planta</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($punto = mysqli_fetch_assoc($puntos)) : ?>
                <tr>
                    <td><?= htmlspecialchars($punto['PDV']) ?></td>
                    <td><?= htmlspecialchars($punto['descripcion']) ?></td>
                    <td><?= htmlspecialchars($punto['planta']) ?></td>
                    <td>
                        <a href="menu.php?eliminar=<?= urlencode($punto['PDV']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar punto de venta?')">Eliminar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
